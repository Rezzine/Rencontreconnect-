import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, QrCode, X } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { PayPalButtons, PayPalScriptProvider } from '@paypal/react-paypal-js';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  duration: number;
  features: string[];
}

// Types pour les transactions
interface Transaction {
  id: number;
  userId: number;
  paypalOrderId: string;
  amount: number;
  currency: string;
  status: string;
  planId: string;
  createdAt: Date;
  completedAt: Date | null;
}

const Premium = () => {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [showWeChatQR, setShowWeChatQR] = useState<boolean>(false);
  const [wechatQRCode, setWechatQRCode] = useState<string>('');
  const [wechatOrderId, setWechatOrderId] = useState<string>('');
  const wechatCheckIntervalRef = useRef<number | null>(null);
  
  // Récupérer l'utilisateur actuel depuis localStorage au chargement
  useEffect(() => {
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      try {
        const user = JSON.parse(userString);
        setCurrentUser(user);
      } catch (error) {
        console.error("Erreur lors de la récupération de l'utilisateur", error);
      }
    }
  }, []);
  
  // Requête pour récupérer les plans d'abonnement
  const { data: plans, isLoading, error } = useQuery({
    queryKey: ['/api/subscription/plans'],
    enabled: !!currentUser
  });
  
  // Requête pour récupérer les transactions de l'utilisateur
  const { data: transactions } = useQuery({
    queryKey: ['/api/transactions/user', currentUser?.id],
    enabled: !!currentUser?.id
  });
  
  // Mutation pour créer une commande PayPal
  const createOrderMutation = useMutation({
    mutationFn: async (planId: string) => {
      if (!currentUser?.id) {
        throw new Error("Utilisateur non connecté");
      }
      
      return await apiRequest('/api/paypal/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, planId })
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: ['/api/transactions/user', currentUser?.id]
      });
      
      // Trouver le lien d'approbation pour rediriger l'utilisateur
      const approvalLink = data.links.find((link: any) => link.rel === 'approve');
      if (approvalLink) {
        window.location.href = approvalLink.href;
      }
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la création de la commande.",
        variant: "destructive"
      });
    }
  });
  
  // Mutation pour capturer une commande PayPal après approbation
  const captureOrderMutation = useMutation({
    mutationFn: async (orderId: string) => {
      return await apiRequest('/api/paypal/capture-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['/api/transactions/user', currentUser?.id]
      });
      
      toast({
        title: "Paiement réussi",
        description: "Votre abonnement premium a été activé avec succès.",
        variant: "default"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la capture du paiement.",
        variant: "destructive"
      });
    }
  });
  
  // Gestion des clics sur les cartes de plan
  const handlePlanSelect = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
  };
  
  // Gestion de l'achat direct (sans PayPal SDK)
  const handlePurchase = async () => {
    if (!selectedPlan) return;
    
    try {
      await createOrderMutation.mutateAsync(selectedPlan.id);
    } catch (error) {
      console.error("Erreur lors de l'achat", error);
    }
  };
  
  // Fonctions pour PayPal
  const createOrder = async () => {
    if (!selectedPlan || !currentUser?.id) return;
    
    try {
      const response = await createOrderMutation.mutateAsync(selectedPlan.id);
      return response.orderId;
    } catch (error) {
      console.error("Erreur lors de la création de la commande PayPal", error);
      throw error;
    }
  };
  
  const onApprove = async (data: any) => {
    try {
      await captureOrderMutation.mutateAsync(data.orderID);
    } catch (error) {
      console.error("Erreur lors de la capture du paiement PayPal", error);
    }
  };
  
  // Mutation pour créer une commande WeChat Pay
  const createWeChatOrderMutation = useMutation({
    mutationFn: async (planId: string) => {
      if (!currentUser?.id) {
        throw new Error("Utilisateur non connecté");
      }
      
      return await apiRequest('/api/wechatpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, planId })
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: ['/api/transactions/user', currentUser?.id]
      });
      
      // Afficher le QR code WeChat
      setWechatQRCode(data.qrCodeURL);
      setWechatOrderId(data.orderId);
      setShowWeChatQR(true);
      
      // Mettre en place une vérification périodique du statut de la transaction
      if (wechatCheckIntervalRef.current) {
        window.clearInterval(wechatCheckIntervalRef.current);
      }
      
      const intervalId = window.setInterval(() => {
        checkWeChatPaymentStatus(data.orderId);
      }, 3000); // Vérifier toutes les 3 secondes
      
      wechatCheckIntervalRef.current = intervalId;
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur s'est produite lors de la création du paiement WeChat.",
        variant: "destructive"
      });
    }
  });
  
  // Vérifier le statut du paiement WeChat
  const checkWeChatPaymentStatus = async (outTradeNo: string) => {
    try {
      const response = await apiRequest(`/api/wechatpay/order-status/${outTradeNo}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.status === 'SUCCESS' || response.orderStatus === 'completed') {
        // Paiement réussi
        if (wechatCheckIntervalRef.current) {
          window.clearInterval(wechatCheckIntervalRef.current);
          wechatCheckIntervalRef.current = null;
        }
        
        setShowWeChatQR(false);
        
        queryClient.invalidateQueries({
          queryKey: ['/api/transactions/user', currentUser?.id]
        });
        
        toast({
          title: "Paiement réussi",
          description: "Votre abonnement premium a été activé avec succès.",
          variant: "default"
        });
      }
    } catch (error) {
      console.error("Erreur lors de la vérification du paiement WeChat:", error);
    }
  };
  
  // Fonction pour afficher le QR code WeChat Pay
  const handleWeChatPay = async () => {
    if (!selectedPlan) return;
    
    try {
      await createWeChatOrderMutation.mutateAsync(selectedPlan.id);
    } catch (error) {
      console.error("Erreur lors du paiement WeChat Pay", error);
    }
  };
  
  // Nettoyage du timer au démontage du composant
  useEffect(() => {
    return () => {
      if (wechatCheckIntervalRef.current) {
        window.clearInterval(wechatCheckIntervalRef.current);
      }
    };
  }, []);
  
  if (isLoading) return <div className="flex justify-center p-10">Chargement des offres...</div>;
  
  if (error) return (
    <div className="flex flex-col items-center p-10">
      <h2 className="text-xl font-bold text-red-500 mb-2">Erreur</h2>
      <p>Une erreur s'est produite lors du chargement des offres.</p>
    </div>
  );
  
  if (!currentUser) {
    return (
      <div className="flex flex-col items-center p-10">
        <h2 className="text-xl font-bold mb-4">Connectez-vous pour accéder aux offres premium</h2>
        <Button variant="default" onClick={() => window.location.href = "/"}>
          Se connecter
        </Button>
      </div>
    );
  }
  
  const hasActivePremium = currentUser.isPremium && 
                          currentUser.premiumUntil && 
                          new Date(currentUser.premiumUntil) > new Date();
  
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Passez à Premium</h1>
      
      {hasActivePremium && (
        <div className="bg-green-100 dark:bg-green-900 p-4 rounded-lg mb-8 text-center">
          <h2 className="text-xl font-semibold mb-2">Vous êtes déjà membre Premium! 🎉</h2>
          <p>
            Votre abonnement est actif jusqu'au {' '}
            {new Date(currentUser.premiumUntil).toLocaleDateString()}
          </p>
        </div>
      )}
      
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {plans?.map((plan: SubscriptionPlan) => (
          <Card 
            key={plan.id}
            className={`flex flex-col ${selectedPlan?.id === plan.id ? 'border-primary' : ''}`}
          >
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>
                Abonnement de {plan.duration} jours
              </CardDescription>
              <div className="mt-2">
                <div className="text-3xl font-bold">{plan.price.toFixed(2)} €</div>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                variant={selectedPlan?.id === plan.id ? "default" : "outline"} 
                className="w-full"
                onClick={() => handlePlanSelect(plan)}
                disabled={hasActivePremium}
              >
                {selectedPlan?.id === plan.id ? 'Sélectionné' : 'Sélectionner'}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      {selectedPlan && !hasActivePremium && (
        <div className="bg-muted p-6 rounded-lg mb-8">
          <h2 className="text-xl font-bold mb-4">Paiement pour {selectedPlan.name}</h2>
          <div className="mb-4">
            <p className="text-lg mb-2">Récapitulatif :</p>
            <ul className="space-y-1 mb-4">
              <li>Plan : {selectedPlan.name}</li>
              <li>Prix : {selectedPlan.price.toFixed(2)} €</li>
              <li>Durée : {selectedPlan.duration} jours</li>
            </ul>
          </div>
          
          <div className="mb-4">
            <Button 
              className="w-full mb-4" 
              onClick={handlePurchase}
              disabled={createOrderMutation.isPending}
            >
              {createOrderMutation.isPending ? 'Traitement...' : `Payer ${selectedPlan.price.toFixed(2)} €`}
            </Button>
            
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2">Ou payer avec</span>
              </div>
            </div>
            
            <PayPalScriptProvider options={{ 
              clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID || '', 
              currency: 'EUR' 
            }}>
              <PayPalButtons
                style={{ layout: 'horizontal' }}
                createOrder={createOrder}
                onApprove={onApprove}
                disabled={createOrderMutation.isPending || createWeChatOrderMutation.isPending}
              />
            </PayPalScriptProvider>
            
            {/* Option de paiement WeChat pour les utilisateurs chinois */}
            {currentUser.country === 'CN' && (
              <>
                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2">Ou</span>
                  </div>
                </div>
                
                <Button 
                  className="w-full flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600"
                  onClick={handleWeChatPay}
                  disabled={createOrderMutation.isPending || createWeChatOrderMutation.isPending}
                >
                  <QrCode className="h-5 w-5" />
                  Payer avec WeChat Pay
                </Button>
              </>
            )}
          </div>
        </div>
      )}
      
      {transactions && transactions.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Historique des transactions</h2>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-muted">
                  <th className="p-2 text-left">Date</th>
                  <th className="p-2 text-left">Plan</th>
                  <th className="p-2 text-left">Montant</th>
                  <th className="p-2 text-left">Statut</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((transaction: Transaction) => (
                  <tr key={transaction.id} className="border-b">
                    <td className="p-2">
                      {new Date(transaction.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-2">{transaction.planId}</td>
                    <td className="p-2">{transaction.amount.toFixed(2)} {transaction.currency}</td>
                    <td className="p-2">
                      <Badge 
                        variant={
                          transaction.status === 'completed' ? 'default' : 
                          transaction.status === 'pending' ? 'outline' : 'destructive'
                        }
                      >
                        {transaction.status === 'completed' ? 'Complété' : 
                         transaction.status === 'pending' ? 'En attente' : 'Échoué'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Modal pour afficher le QR code WeChat Pay */}
      <Dialog open={showWeChatQR} onOpenChange={setShowWeChatQR}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Scanner le code QR avec WeChat Pay</DialogTitle>
            <DialogDescription>
              Veuillez scanner ce code QR avec l'application WeChat Pay pour finaliser votre paiement.
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center p-4">
            {wechatQRCode ? (
              <div className="relative">
                <img 
                  src={wechatQRCode} 
                  alt="QR Code WeChat Pay" 
                  className="w-64 h-64 object-contain"
                />
                <div className="mt-4 text-center text-sm text-muted-foreground">
                  Après le paiement, votre abonnement sera activé automatiquement.
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center w-64 h-64 bg-muted">
                <p>Chargement du QR code...</p>
              </div>
            )}
          </div>
          
          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setShowWeChatQR(false)}>
              Annuler
            </Button>
            <Button 
              variant="ghost"
              onClick={() => {
                if (wechatOrderId) {
                  checkWeChatPaymentStatus(wechatOrderId);
                }
              }}
            >
              Vérifier le paiement
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Premium;