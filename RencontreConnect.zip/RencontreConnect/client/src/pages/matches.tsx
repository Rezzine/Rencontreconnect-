import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { User, Match } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Heart, Star, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { queryClient } from "@/lib/queryClient";

interface MatchWithUser extends Match {
  otherUser: User | null;
}

const Matches = () => {
  const [activeTab, setActiveTab] = useState("recent");
  const [favorites, setFavorites] = useState<number[]>([]);

  // Mock user ID - in a real application, this would come from auth context
  const userId = 1;

  const { data: matches, isLoading } = useQuery<MatchWithUser[]>({
    queryKey: [`/api/matches/${userId}`],
  });

  const { data: receivedLikes } = useQuery<any[]>({
    queryKey: [`/api/likes/received/${userId}`],
  });

  const recentMatches = matches?.filter(match => {
    const date = new Date(match.createdAt);
    const now = new Date();
    const daysDiff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    return daysDiff <= 7;
  });

  const favoriteMatches = matches?.filter(match => 
    favorites.includes(match.id)
  );

  const toggleFavorite = (matchId: number) => {
    if (favorites.includes(matchId)) {
      setFavorites(favorites.filter(id => id !== matchId));
    } else {
      setFavorites([...favorites, matchId]);
    }
  };

  return (
    <div>
      {/* Matches Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-neutral-900">Mes Matches</h1>
        <p className="text-neutral-600">Consultez vos connexions mutuelles et commencez à discuter</p>
      </div>

      {/* Match Tabs */}
      <Tabs defaultValue="recent" onValueChange={setActiveTab} value={activeTab}>
        <TabsList className="border-b border-neutral-200 mb-6 pb-0 w-full justify-start">
          <TabsTrigger value="recent" className="relative rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4">
            Récents 
            {recentMatches && recentMatches.length > 0 && (
              <Badge variant="secondary" className="ml-2 bg-primary/10 text-primary">
                {recentMatches.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="favorites" className="relative rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4">
            Favoris
            {favoriteMatches && favoriteMatches.length > 0 && (
              <Badge variant="secondary" className="ml-2 bg-neutral-100 text-neutral-600">
                {favoriteMatches.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="pending" className="relative rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4">
            En attente
            {receivedLikes && receivedLikes.length > 0 && (
              <Badge variant="secondary" className="ml-2 bg-neutral-100 text-neutral-600">
                {receivedLikes.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="recent" className="pt-2">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-neutral-900">Nouveaux matches</h2>
            </div>
            
            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {[...Array(4)].map((_, i) => (
                  <div 
                    key={i} 
                    className="bg-white rounded-xl shadow-sm overflow-hidden animate-pulse"
                  >
                    <div className="aspect-square bg-neutral-200"></div>
                    <div className="p-4 text-center">
                      <div className="h-5 bg-neutral-200 rounded mx-auto w-2/3 mb-3"></div>
                      <div className="h-8 bg-neutral-200 rounded mx-auto w-full"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : recentMatches && recentMatches.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {recentMatches.map((match, index) => (
                  <div 
                    key={match.id}
                    className={`bg-white rounded-xl shadow-sm overflow-hidden ${index === 0 ? 'match-animation border-2 border-primary' : ''}`}
                  >
                    <div className="relative">
                      {index === 0 && (
                        <div className="absolute top-2 right-2 bg-primary text-white text-xs font-medium px-2 py-1 rounded-full">
                          Nouveau!
                        </div>
                      )}
                      <img 
                        src={match.otherUser?.profilePicture || 'https://via.placeholder.com/300'} 
                        alt={match.otherUser?.fullName || 'Profile photo'} 
                        className="aspect-square w-full object-cover object-center"
                      />
                    </div>
                    <div className="p-4 text-center">
                      <h3 className="font-semibold text-base">
                        {match.otherUser ? match.otherUser.fullName.split(' ')[0] : 'Utilisateur'}, 
                        {match.otherUser ? new Date().getFullYear() - new Date(match.otherUser.birthDate).getFullYear() : '?'}
                      </h3>
                      <div className="flex justify-center space-x-2 mt-3">
                        <Link href={`/messages?matchId=${match.id}`}>
                          <Button className="w-full flex items-center">
                            <MessageCircle className="mr-1 h-4 w-4" /> Message
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-white rounded-xl shadow-sm">
                <div className="text-4xl mb-4">😊</div>
                <h3 className="text-xl font-semibold mb-2">Pas de nouveaux matches pour le moment</h3>
                <p className="text-neutral-600 mb-4">
                  Découvrez plus de profils pour trouver votre match idéal!
                </p>
                <Link href="/discover">
                  <Button>
                    Découvrir des profils
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="favorites" className="pt-2">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-neutral-900">Matches favoris</h2>
            </div>
            
            {favoriteMatches && favoriteMatches.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {favoriteMatches.map((match) => (
                  <div 
                    key={match.id}
                    className="bg-white rounded-xl shadow-sm overflow-hidden"
                  >
                    <div className="relative">
                      <img 
                        src={match.otherUser?.profilePicture || 'https://via.placeholder.com/300'} 
                        alt={match.otherUser?.fullName || 'Profile photo'} 
                        className="aspect-square w-full object-cover object-center"
                      />
                      <button
                        onClick={() => toggleFavorite(match.id)}
                        className="absolute top-2 right-2 p-2 bg-white/80 rounded-full text-yellow-500 hover:bg-white"
                      >
                        <Star className="h-5 w-5 fill-current" />
                      </button>
                    </div>
                    <div className="p-4 text-center">
                      <h3 className="font-semibold text-base">
                        {match.otherUser ? match.otherUser.fullName.split(' ')[0] : 'Utilisateur'}, 
                        {match.otherUser ? new Date().getFullYear() - new Date(match.otherUser.birthDate).getFullYear() : '?'}
                      </h3>
                      <div className="flex justify-center space-x-2 mt-3">
                        <Link href={`/messages?matchId=${match.id}`}>
                          <Button className="w-full flex items-center">
                            <MessageCircle className="mr-1 h-4 w-4" /> Message
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-white rounded-xl shadow-sm">
                <div className="text-4xl mb-4">⭐</div>
                <h3 className="text-xl font-semibold mb-2">Pas de favoris pour le moment</h3>
                <p className="text-neutral-600 mb-4">
                  Marquez vos matches préférés en favoris pour les retrouver facilement!
                </p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="pending" className="pt-2">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-neutral-900">En attente de réponse</h2>
            </div>
            
            {receivedLikes && receivedLikes.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
                {receivedLikes.map((like) => (
                  <div 
                    key={like.id}
                    className="bg-white rounded-xl shadow-sm overflow-hidden opacity-70 hover:opacity-100 transition-opacity"
                  >
                    <div className="relative">
                      <img 
                        src={like.user?.profilePicture || 'https://via.placeholder.com/300'} 
                        alt={like.user?.fullName || 'Profile photo'} 
                        className="aspect-square w-full object-cover object-center"
                      />
                      <div className="absolute inset-0 bg-neutral-900/20 flex items-center justify-center">
                        <span className="bg-white/90 text-neutral-800 text-xs font-medium px-2 py-1 rounded-full flex items-center">
                          <Clock className="mr-1 h-3 w-3" />
                          En attente
                        </span>
                      </div>
                    </div>
                    <div className="p-3 text-center">
                      <h3 className="font-medium text-sm text-neutral-800">
                        {like.user ? like.user.fullName.split(' ')[0] : 'Utilisateur'}, 
                        {like.user ? new Date().getFullYear() - new Date(like.user.birthDate).getFullYear() : '?'}
                      </h3>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-white rounded-xl shadow-sm">
                <div className="text-4xl mb-4">👍</div>
                <h3 className="text-xl font-semibold mb-2">Pas de likes en attente</h3>
                <p className="text-neutral-600 mb-4">
                  Vous avez répondu à tous vos likes reçus !
                </p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Matches;
