import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Match, Message, User } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Search,
  Info,
  Video,
  Phone,
  Image,
  Send,
  ChevronRight
} from "lucide-react";

interface MatchWithUser extends Match {
  otherUser: User | null;
}

const formatDate = (date: Date) => {
  const now = new Date();
  const diff = Math.abs(now.getTime() - new Date(date).getTime());
  const diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) {
    return "Aujourd'hui";
  } else if (diffDays === 1) {
    return "Hier";
  } else if (diffDays < 7) {
    return new Date(date).toLocaleDateString('fr-FR', { weekday: 'short' });
  } else {
    return new Date(date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  }
};

const formatTime = (date: Date) => {
  return new Date(date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
};

const Messages = () => {
  // Mock user ID - in a real application, this would come from auth context
  const userId = 1;
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMatchId, setSelectedMatchId] = useState<number | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [messageContent, setMessageContent] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [location] = useLocation();

  // Extract matchId from URL if present
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const matchId = params.get('matchId');
    if (matchId) {
      setSelectedMatchId(parseInt(matchId));
    }
  }, [location]);

  const { data: matches, isLoading: isLoadingMatches } = useQuery<MatchWithUser[]>({
    queryKey: [`/api/matches/${userId}`],
  });

  const { data: messages, isLoading: isLoadingMessages } = useQuery<Message[]>({
    queryKey: [`/api/messages/match/${selectedMatchId}`],
    enabled: !!selectedMatchId
  });

  useEffect(() => {
    if (matches && matches.length > 0) {
      if (selectedMatchId) {
        const match = matches.find(m => m.id === selectedMatchId);
        if (match && match.otherUser) {
          setSelectedUser(match.otherUser);
        }
      } else if (!selectedMatchId) {
        // Default to first match if none selected
        setSelectedMatchId(matches[0].id);
        setSelectedUser(matches[0].otherUser);
      }
    }
  }, [matches, selectedMatchId]);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedMatchId || !selectedUser) return;
      
      const messageData = {
        matchId: selectedMatchId,
        senderId: userId,
        receiverId: selectedUser.id,
        content
      };
      
      const response = await apiRequest('POST', '/api/messages', messageData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/messages/match/${selectedMatchId}`] });
      setMessageContent("");
    }
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageContent.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(messageContent);
    }
  };

  const filteredMatches = matches?.filter(match => {
    if (!searchQuery) return true;
    if (!match.otherUser) return false;
    
    return match.otherUser.fullName.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 h-[calc(100vh-12rem)]">
        {/* Conversation List */}
        <div className="md:col-span-1 border-r border-neutral-200 flex flex-col h-full">
          <div className="p-4 border-b border-neutral-200">
            <h2 className="text-lg font-semibold text-neutral-900">Messages</h2>
            <div className="relative mt-2">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-neutral-400" />
              </div>
              <Input 
                placeholder="Rechercher..." 
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <ScrollArea className="flex-1">
            {isLoadingMatches ? (
              [...Array(4)].map((_, i) => (
                <div key={i} className="p-4 border-b border-neutral-200 animate-pulse">
                  <div className="flex items-start">
                    <div className="h-12 w-12 rounded-full bg-neutral-200 mr-3"></div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <div className="h-4 bg-neutral-200 rounded w-1/3 mb-2"></div>
                        <div className="h-3 bg-neutral-200 rounded w-12"></div>
                      </div>
                      <div className="h-3 bg-neutral-200 rounded w-2/3"></div>
                    </div>
                  </div>
                </div>
              ))
            ) : filteredMatches && filteredMatches.length > 0 ? (
              filteredMatches.map((match) => (
                <div 
                  key={match.id}
                  className={`p-4 border-b border-neutral-200 hover:bg-neutral-50 cursor-pointer ${selectedMatchId === match.id ? 'bg-primary/5' : ''}`}
                  onClick={() => {
                    setSelectedMatchId(match.id);
                    setSelectedUser(match.otherUser);
                  }}
                >
                  <div className="flex items-start">
                    <div className="relative mr-3">
                      <img 
                        src={match.otherUser?.profilePicture || 'https://via.placeholder.com/300'} 
                        alt={match.otherUser?.fullName || 'Profile'} 
                        className="h-12 w-12 rounded-full object-cover"
                      />
                      <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white ${match.otherUser?.isOnline ? 'bg-green-500' : 'bg-neutral-300'}`}></div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <h3 className="text-base font-semibold text-neutral-900 truncate">
                          {match.otherUser ? match.otherUser.fullName.split(' ')[0] : 'Utilisateur'}
                        </h3>
                        <span className="text-xs text-neutral-500">
                          {formatDate(new Date(match.createdAt))}
                        </span>
                      </div>
                      <p className="text-sm text-neutral-600 truncate">
                        {/* Show last message if any */}
                        Commencez une conversation...
                      </p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center">
                <p className="text-neutral-600">Aucune conversation pour le moment</p>
                <Button variant="link" asChild>
                  <a href="/discover">Découvrir des profils</a>
                </Button>
              </div>
            )}
          </ScrollArea>
        </div>
        
        {/* Chat Area */}
        <div className="md:col-span-2 lg:col-span-3 flex flex-col h-full">
          {selectedMatchId && selectedUser ? (
            <>
              {/* Conversation Header */}
              <div className="p-4 border-b border-neutral-200 flex items-center">
                <img 
                  src={selectedUser.profilePicture || 'https://via.placeholder.com/300'} 
                  alt={selectedUser.fullName || 'Profile'} 
                  className="h-12 w-12 rounded-full object-cover mr-3"
                />
                <div className="flex-1">
                  <div className="flex items-center">
                    <h3 className="text-lg font-semibold text-neutral-900">
                      {selectedUser.fullName.split(' ')[0]}
                    </h3>
                    <div className={`ml-2 h-2 w-2 rounded-full ${selectedUser.isOnline ? 'bg-green-500' : 'bg-neutral-300'}`}></div>
                  </div>
                  <p className="text-sm text-neutral-500">
                    {selectedUser.isOnline ? 'En ligne' : 'Hors ligne'}
                  </p>
                </div>
                <div className="flex">
                  <Button variant="ghost" size="icon">
                    <Info className="h-5 w-5 text-neutral-500" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-5 w-5 text-neutral-500" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Phone className="h-5 w-5 text-neutral-500" />
                  </Button>
                </div>
              </div>
              
              {/* Messages */}
              <ScrollArea className="flex-1 p-4 bg-neutral-50">
                <div className="space-y-4">
                  {isLoadingMessages ? (
                    [...Array(3)].map((_, i) => (
                      <div key={i} className={`flex items-end ${i % 2 === 0 ? '' : 'justify-end'}`}>
                        {i % 2 === 0 && <div className="h-8 w-8 rounded-full bg-neutral-200 mr-2"></div>}
                        <div className={`max-w-[75%] ${i % 2 === 0 ? '' : 'text-right'}`}>
                          <div className={`p-3 rounded-xl shadow-sm ${i % 2 === 0 ? 'bg-neutral-200' : 'bg-primary/70'} h-10 w-40`}></div>
                          <div className="h-3 w-8 bg-neutral-200 rounded mt-1"></div>
                        </div>
                      </div>
                    ))
                  ) : messages && messages.length > 0 ? (
                    <>
                      {/* Date separator */}
                      <div className="flex justify-center">
                        <span className="bg-neutral-200 text-neutral-600 text-xs px-4 py-1 rounded-full">
                          {formatDate(new Date(messages[0].createdAt))}
                        </span>
                      </div>
                      
                      {/* Message bubbles */}
                      {messages.map((message) => (
                        <div 
                          key={message.id}
                          className={`flex items-end ${message.senderId === userId ? 'justify-end' : ''}`}
                        >
                          {message.senderId !== userId && (
                            <img 
                              src={selectedUser.profilePicture || 'https://via.placeholder.com/300'} 
                              alt={selectedUser.fullName || 'Profile'} 
                              className="h-8 w-8 rounded-full object-cover mr-2"
                            />
                          )}
                          <div className={`max-w-[75%] ${message.senderId === userId ? 'text-right' : ''}`}>
                            <div 
                              className={`p-3 rounded-xl shadow-sm ${
                                message.senderId === userId 
                                  ? 'bg-primary text-white rounded-tr-none' 
                                  : 'bg-neutral-100 text-neutral-800 rounded-tl-none'
                              }`}
                            >
                              <p>{message.content}</p>
                            </div>
                            <span className="text-xs text-neutral-500 mx-2">
                              {formatTime(new Date(message.createdAt))}
                            </span>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full py-12">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-4">
                        <MessageCircle className="h-8 w-8" />
                      </div>
                      <h3 className="text-lg font-semibold text-neutral-900 mb-2">
                        Commencez une conversation
                      </h3>
                      <p className="text-neutral-600 text-center max-w-md">
                        Envoyez un message pour démarrer la conversation avec {selectedUser.fullName.split(' ')[0]}
                      </p>
                    </div>
                  )}
                </div>
              </ScrollArea>
              
              {/* Message Input */}
              <div className="p-4 border-t border-neutral-200">
                <form className="flex items-end" onSubmit={handleSendMessage}>
                  <Button type="button" variant="ghost" size="icon" className="mr-2">
                    <Image className="h-5 w-5 text-neutral-500" />
                  </Button>
                  <div className="flex-1 relative">
                    <Input
                      placeholder="Écrivez votre message..."
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                  <Button 
                    type="submit" 
                    size="icon"
                    className="ml-2 rounded-full"
                    disabled={messageContent.trim() === '' || sendMessageMutation.isPending}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full py-12">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-4">
                <MessageCircle className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-neutral-900 mb-2">
                Vos messages
              </h3>
              <p className="text-neutral-600 text-center max-w-md mb-6">
                Sélectionnez une conversation pour commencer à chatter ou découvrez de nouveaux profils
              </p>
              <Button asChild>
                <a href="/discover">
                  Découvrir des profils <ChevronRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Add missing MessageCircle component
const MessageCircle = (props: any) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
  </svg>
);

export default Messages;
