import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import ProfileCard from "@/components/profile/profile-card";
import { User } from "@shared/schema";
import { Heart } from "lucide-react";
import { RevenueTracker } from "../components/RevenueTracker";

const Home = () => {
  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const getAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div>
      {/* Hero Section */}
      <div className="py-12 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary/5 to-[#6C63FF]/5 rounded-3xl mb-12">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 tracking-tight mb-4">
            Trouvez l'amour qui vous <span className="text-primary">correspond</span>
          </h1>
          <p className="mt-4 text-lg text-neutral-600 max-w-2xl mx-auto">
            Rendez-Vous vous aide à rencontrer des personnes partageant vos intérêts et vos valeurs pour des connexions authentiques.
          </p>
          <div className="mt-10 flex gap-4 justify-center">
            <Link href="/profile/create">
              <a className="bg-primary hover:bg-primary/90 text-white rounded-lg text-base font-medium px-6 py-3 text-center transition-all hover:-translate-y-1">
                Créer un compte
              </a>
            </Link>
            <Link href="/discover">
              <a className="bg-white text-neutral-800 hover:bg-neutral-100 border border-neutral-300 rounded-lg text-base font-medium px-6 py-3 text-center transition-all hover:-translate-y-1">
                En savoir plus
              </a>
            </Link>
          </div>
        </div>
      </div>

      {/* Featured Profiles */}
      <div className="mb-16">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-neutral-900">Profils populaires</h2>
          <Link href="/discover">
            <a className="text-[#6C63FF] font-medium flex items-center">
              Voir plus <Heart className="ml-2 h-4 w-4" />
            </a>
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div 
                key={i} 
                className="bg-white rounded-xl shadow-sm overflow-hidden animate-pulse h-96"
              >
                <div className="bg-neutral-200 h-3/4"></div>
                <div className="p-4">
                  <div className="h-4 bg-neutral-200 rounded mb-3"></div>
                  <div className="h-3 bg-neutral-200 rounded mb-4 w-1/2"></div>
                  <div className="flex space-x-2 mb-3">
                    <div className="h-6 bg-neutral-200 rounded w-16"></div>
                    <div className="h-6 bg-neutral-200 rounded w-20"></div>
                    <div className="h-6 bg-neutral-200 rounded w-14"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {users && users.slice(0, 4).map((user) => (
              <ProfileCard 
                key={user.id}
                name={user.fullName.split(' ')[0]}
                age={getAge(user.birthDate)}
                location={user.location}
                photo={user.profilePicture || ''}
                interests={user.interests || []}
                isOnline={user.isOnline}
              />
            ))}
          </div>
        )}
      </div>

      {/* How It Works */}
      <div className="mb-16">
        <h2 className="text-2xl font-semibold text-neutral-900 mb-8 text-center">Comment ça marche</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary text-2xl mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Créez votre profil</h3>
            <p className="text-neutral-600">Présentez-vous avec des photos et partagez vos intérêts pour trouver des personnes compatibles.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-16 h-16 bg-[#6C63FF]/10 rounded-full flex items-center justify-center text-[#6C63FF] text-2xl mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Trouvez des matches</h3>
            <p className="text-neutral-600">Notre algorithme vous présente des profils correspondant à vos préférences.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-16 h-16 bg-[#00D1B2]/10 rounded-full flex items-center justify-center text-[#00D1B2] text-2xl mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Commencez à discuter</h3>
            <p className="text-neutral-600">Échangez des messages pour faire connaissance et organisez une rencontre en personne.</p>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="mb-16">
        <h2 className="text-2xl font-semibold text-neutral-900 mb-8 text-center">Histoires de succès</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center mb-4">
              <img src="https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80" alt="Sophie et Pierre" className="w-16 h-16 rounded-full object-cover mr-4" />
              <div>
                <h3 className="text-lg font-semibold">Sophie et Pierre</h3>
                <p className="text-neutral-500 text-sm">Ensemble depuis 2 ans</p>
              </div>
            </div>
            <p className="text-neutral-600 italic">"Nous nous sommes rencontrés sur Rendez-Vous en avril 2021. Dès notre premier rendez-vous, nous avons ressenti une connexion spéciale. Aujourd'hui, nous vivons ensemble et prévoyons de nous marier l'été prochain!"</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center mb-4">
              <img src="https://images.unsplash.com/photo-1528555253298-9f7c376dc7ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80" alt="Marie et Antoine" className="w-16 h-16 rounded-full object-cover mr-4" />
              <div>
                <h3 className="text-lg font-semibold">Marie et Antoine</h3>
                <p className="text-neutral-500 text-sm">Ensemble depuis 1 an</p>
              </div>
            </div>
            <p className="text-neutral-600 italic">"J'étais sceptique à propos des sites de rencontre, mais j'ai décidé d'essayer Rendez-Vous. J'ai rencontré Antoine après seulement deux semaines, et notre relation est allée de mieux en mieux depuis. Merci Rendez-Vous!"</p>
          </div>
        </div>
      </div>

      {/* Revenue Tracker */}
      <RevenueTracker />

      {/* Call To Action */}
      <div className="bg-gradient-to-r from-primary to-[#6C63FF] rounded-3xl p-8 md:p-12 text-white text-center mb-16">
        <h2 className="text-3xl font-bold mb-4">Prêt à trouver l'amour?</h2>
        <p className="text-white/90 max-w-2xl mx-auto mb-8">Rejoignez des milliers de célibataires qui ont déjà trouvé leur moitié sur Rendez-Vous. L'inscription est gratuite et ne prend que quelques minutes.</p>
        <Link href="/profile/create">
          <a className="bg-white text-primary hover:bg-neutral-100 font-semibold px-8 py-3 rounded-lg text-lg transition-all inline-block">
            Commencer maintenant
          </a>
        </Link>
      </div>
    </div>
  );
};

export default Home;