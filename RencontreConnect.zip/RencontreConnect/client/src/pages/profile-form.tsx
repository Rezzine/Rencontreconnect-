import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertUserSchema } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusIcon, X } from "lucide-react";
import InterestTag from "@/components/profile/interest-tag";
import { useToast } from "@/hooks/use-toast";

const interestOptions = [
  "Sport", "Musique", "Cinéma", "Voyage", "Art", 
  "Cuisine", "Lecture", "Danse", "Photographie", 
  "Technologie", "Mode", "Yoga", "Randonnée", "Gastronomie", "Nature"
];

// Extend the insertUserSchema with additional validation
const profileFormSchema = insertUserSchema.extend({
  // Add custom validations
  birthDate: z.string().refine(value => {
    const date = new Date(value);
    const now = new Date();
    const age = now.getFullYear() - date.getFullYear();
    return age >= 18;
  }, { message: "Vous devez avoir au moins 18 ans" }),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

type ProfileFormData = z.infer<typeof profileFormSchema>;

const ProfileForm = () => {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const isEditMode = location.includes("/edit");

  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [photos, setPhotos] = useState<{ id: number; url: string }[]>([
    { id: 1, url: "" },
    { id: 2, url: "" },
    { id: 3, url: "" },
    { id: 4, url: "" },
    { id: 5, url: "" },
    { id: 6, url: "" },
  ]);

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      birthDate: "",
      gender: "Homme",
      interestedIn: "Femmes",
      location: "",
      bio: "",
      profilePicture: "",
      photos: [],
      interests: [],
      hideLocation: false,
      hideOnlineStatus: false,
      showInSearch: true,
    },
  });

  // If in edit mode, fetch user data
  useEffect(() => {
    if (isEditMode) {
      // In a real application, fetch user data from API
      // For now, we'll just pre-fill with mock data
      form.reset({
        username: "user123",
        password: "password",
        confirmPassword: "password",
        fullName: "John Doe",
        birthDate: "1990-01-01",
        gender: "Homme",
        interestedIn: "Femmes",
        location: "Paris, France",
        bio: "I love hiking and traveling!",
        profilePicture: "",
        photos: [],
        interests: ["Voyage", "Sport"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true,
      });
      
      setSelectedInterests(["Voyage", "Sport"]);
    }
  }, [isEditMode, form]);

  const toggleInterest = (interest: string) => {
    if (selectedInterests.includes(interest)) {
      setSelectedInterests(selectedInterests.filter(i => i !== interest));
    } else {
      if (selectedInterests.length < 8) {
        setSelectedInterests([...selectedInterests, interest]);
      }
    }
  };

  const handlePhotoChange = (id: number, url: string) => {
    setPhotos(photos.map(photo => 
      photo.id === id ? { ...photo, url } : photo
    ));
  };

  const onSubmit = async (data: ProfileFormData) => {
    try {
      // Set the interests from the selected interests
      data.interests = selectedInterests;
      
      // Set the photos from the photos array
      data.photos = photos.map(p => p.url).filter(url => url !== "");
      
      // Set the profile picture to the first photo if exists
      data.profilePicture = photos[0].url || "";
      
      delete data.confirmPassword;
      
      if (isEditMode) {
        // Update user
        await apiRequest('PUT', '/api/users/1', data);
        toast({
          title: "Profil mis à jour",
          description: "Votre profil a été mis à jour avec succès.",
        });
      } else {
        // Create new user
        await apiRequest('POST', '/api/auth/register', data);
        toast({
          title: "Inscription réussie",
          description: "Votre compte a été créé avec succès.",
        });
      }
      
      // Redirect to home page after successful submission
      navigate("/");
    } catch (error) {
      console.error("Error submitting form:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue. Veuillez réessayer.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-neutral-900">
          {isEditMode ? "Modifier votre profil" : "Créer votre profil"}
        </h1>
        <p className="text-neutral-600">
          {isEditMode 
            ? "Mettez à jour vos informations pour améliorer vos chances de trouver des matches"
            : "Partagez vos informations pour trouver des personnes compatibles"}
        </p>
      </div>
      
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
          <h2 className="text-xl font-semibold mb-6">Photos de profil</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-4">
            {photos.map((photo, index) => (
              <div
                key={photo.id}
                className={`aspect-square bg-neutral-100 rounded-lg border-2 ${
                  index === 0 ? (photo.url ? 'border-primary' : 'border-dashed border-neutral-300') : 'border-dashed border-neutral-300'
                } flex flex-col items-center justify-center cursor-pointer hover:bg-neutral-50 relative overflow-hidden`}
              >
                {photo.url ? (
                  <>
                    <img 
                      src={photo.url} 
                      alt={`Photo ${photo.id}`} 
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      className="absolute top-2 right-2 bg-white/80 rounded-full p-1 hover:bg-white"
                      onClick={() => handlePhotoChange(photo.id, "")}
                    >
                      <X className="h-4 w-4 text-neutral-700" />
                    </button>
                  </>
                ) : (
                  <>
                    <PlusIcon className="text-neutral-400 text-2xl mb-2 h-8 w-8" />
                    {index === 0 ? (
                      <span className="text-sm text-neutral-500">Photo principale</span>
                    ) : null}
                    <input
                      type="text"
                      placeholder="URL de l'image"
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      onChange={(e) => handlePhotoChange(photo.id, e.target.value)}
                    />
                  </>
                )}
              </div>
            ))}
          </div>
          <p className="text-sm text-neutral-500">
            Ajoutez jusqu'à 6 photos. La première sera votre photo principale.
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
          <h2 className="text-xl font-semibold mb-6">Informations personnelles</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {!isEditMode && (
              <>
                <div>
                  <Label htmlFor="username" className="block text-sm font-medium text-neutral-700 mb-1">
                    Nom d'utilisateur
                  </Label>
                  <Input
                    id="username"
                    {...form.register("username")}
                    className={form.formState.errors.username ? "border-red-500" : ""}
                  />
                  {form.formState.errors.username && (
                    <p className="text-red-500 text-sm mt-1">
                      {form.formState.errors.username.message}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="password" className="block text-sm font-medium text-neutral-700 mb-1">
                    Mot de passe
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    {...form.register("password")}
                    className={form.formState.errors.password ? "border-red-500" : ""}
                  />
                  {form.formState.errors.password && (
                    <p className="text-red-500 text-sm mt-1">
                      {form.formState.errors.password.message}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="confirmPassword" className="block text-sm font-medium text-neutral-700 mb-1">
                    Confirmer le mot de passe
                  </Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    {...form.register("confirmPassword")}
                    className={form.formState.errors.confirmPassword ? "border-red-500" : ""}
                  />
                  {form.formState.errors.confirmPassword && (
                    <p className="text-red-500 text-sm mt-1">
                      {form.formState.errors.confirmPassword.message}
                    </p>
                  )}
                </div>
              </>
            )}
            <div className={!isEditMode ? "sm:col-span-2" : ""}>
              <Label htmlFor="fullName" className="block text-sm font-medium text-neutral-700 mb-1">
                Nom complet
              </Label>
              <Input
                id="fullName"
                {...form.register("fullName")}
                className={form.formState.errors.fullName ? "border-red-500" : ""}
              />
              {form.formState.errors.fullName && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.fullName.message}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="birthDate" className="block text-sm font-medium text-neutral-700 mb-1">
                Date de naissance
              </Label>
              <Input
                id="birthDate"
                type="date"
                {...form.register("birthDate")}
                className={form.formState.errors.birthDate ? "border-red-500" : ""}
              />
              {form.formState.errors.birthDate && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.birthDate.message}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="gender" className="block text-sm font-medium text-neutral-700 mb-1">
                Genre
              </Label>
              <Select
                value={form.watch("gender")}
                onValueChange={(value) => form.setValue("gender", value)}
              >
                <SelectTrigger id="gender">
                  <SelectValue placeholder="Sélectionnez votre genre" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Homme">Homme</SelectItem>
                  <SelectItem value="Femme">Femme</SelectItem>
                  <SelectItem value="Non-binaire">Non-binaire</SelectItem>
                  <SelectItem value="Autre">Préfère ne pas préciser</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="interestedIn" className="block text-sm font-medium text-neutral-700 mb-1">
                Je recherche
              </Label>
              <Select
                value={form.watch("interestedIn")}
                onValueChange={(value) => form.setValue("interestedIn", value)}
              >
                <SelectTrigger id="interestedIn">
                  <SelectValue placeholder="Sélectionnez votre préférence" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Hommes">Hommes</SelectItem>
                  <SelectItem value="Femmes">Femmes</SelectItem>
                  <SelectItem value="Tout le monde">Tout le monde</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="location" className="block text-sm font-medium text-neutral-700 mb-1">
                Localisation
              </Label>
              <Input
                id="location"
                placeholder="Ville, Pays"
                {...form.register("location")}
                className={form.formState.errors.location ? "border-red-500" : ""}
              />
              {form.formState.errors.location && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.location.message}
                </p>
              )}
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
          <h2 className="text-xl font-semibold mb-6">À propos de moi</h2>
          <div className="space-y-6">
            <div>
              <Label htmlFor="bio" className="block text-sm font-medium text-neutral-700 mb-1">
                Biographie
              </Label>
              <Textarea
                id="bio"
                rows={4}
                placeholder="Parlez de vous, vos passions, vos objectifs..."
                {...form.register("bio")}
                className={form.formState.errors.bio ? "border-red-500" : ""}
              />
              <p className="text-sm text-neutral-500 mt-1">
                {form.watch("bio")?.length || 0}/500 caractères
              </p>
            </div>
            <div>
              <Label className="block text-sm font-medium text-neutral-700 mb-1">
                Intérêts
              </Label>
              <div className="flex flex-wrap gap-2">
                {interestOptions.map((interest) => (
                  <InterestTag
                    key={interest}
                    interest={interest}
                    selected={selectedInterests.includes(interest)}
                    onSelect={() => toggleInterest(interest)}
                  />
                ))}
              </div>
              <p className="text-sm text-neutral-500 mt-2">
                Sélectionnez jusqu'à 8 intérêts ({selectedInterests.length}/8)
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
          <h2 className="text-xl font-semibold mb-6">Paramètres de confidentialité</h2>
          <div className="space-y-4">
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <Checkbox
                  id="hideLocation"
                  checked={form.watch("hideLocation")}
                  onCheckedChange={(checked) => form.setValue("hideLocation", checked as boolean)}
                />
              </div>
              <div className="ml-3 text-sm">
                <Label htmlFor="hideLocation" className="font-medium text-neutral-700">
                  Masquer ma localisation précise
                </Label>
                <p className="text-neutral-500">
                  Seule la ville sera visible par les autres utilisateurs
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <Checkbox
                  id="hideOnlineStatus"
                  checked={form.watch("hideOnlineStatus")}
                  onCheckedChange={(checked) => form.setValue("hideOnlineStatus", checked as boolean)}
                />
              </div>
              <div className="ml-3 text-sm">
                <Label htmlFor="hideOnlineStatus" className="font-medium text-neutral-700">
                  Masquer mon statut en ligne
                </Label>
                <p className="text-neutral-500">
                  Les autres utilisateurs ne verront pas quand vous êtes actif
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <Checkbox
                  id="showInSearch"
                  checked={form.watch("showInSearch")}
                  onCheckedChange={(checked) => form.setValue("showInSearch", checked as boolean)}
                />
              </div>
              <div className="ml-3 text-sm">
                <Label htmlFor="showInSearch" className="font-medium text-neutral-700">
                  Apparaître dans les recherches
                </Label>
                <p className="text-neutral-500">
                  Permet aux autres utilisateurs de vous trouver
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-4 mb-12">
          <Button 
            type="button" 
            variant="outline"
            onClick={() => navigate("/")}
          >
            Annuler
          </Button>
          <Button type="submit">
            {isEditMode ? "Mettre à jour" : "Enregistrer le profil"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ProfileForm;
