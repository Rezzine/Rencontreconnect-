import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import ProfileCard from "@/components/profile/profile-card";
import InterestTag from "@/components/profile/interest-tag";
import { User } from "@shared/schema";
import { 
  Filter, 
  SortDesc, 
  ChevronDown, 
  X, 
  Search
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";

const interestOptions = [
  "Sport", "Musique", "Cinéma", "Voyage", "Art", 
  "Cuisine", "Lecture", "Danse", "Photographie", 
  "Technologie", "Mode", "Yoga", "Randonnée", "Gastronomie", "Nature"
];

const Discover = () => {
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    ageRange: [18, 50],
    distance: "50",
    gender: [] as string[],
    interests: [] as string[],
    location: ""
  });

  const { data: users, isLoading, refetch } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const toggleFilter = () => {
    setShowFilters(!showFilters);
  };

  const handleResetFilters = () => {
    setFilters({
      ageRange: [18, 50],
      distance: "50",
      gender: [],
      interests: [],
      location: ""
    });
  };

  const handleApplyFilters = () => {
    refetch();
    setShowFilters(false);
  };

  const toggleInterest = (interest: string) => {
    if (filters.interests.includes(interest)) {
      setFilters({
        ...filters,
        interests: filters.interests.filter(i => i !== interest)
      });
    } else {
      if (filters.interests.length < 8) {
        setFilters({
          ...filters,
          interests: [...filters.interests, interest]
        });
      }
    }
  };

  const toggleGender = (gender: string) => {
    if (filters.gender.includes(gender)) {
      setFilters({
        ...filters,
        gender: filters.gender.filter(g => g !== gender)
      });
    } else {
      setFilters({
        ...filters,
        gender: [...filters.gender, gender]
      });
    }
  };

  const getAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  // Function to filter users based on filters
  const filteredUsers = users?.filter(user => {
    const age = getAge(user.birthDate);
    
    // Filter by age range
    if (age < filters.ageRange[0] || age > filters.ageRange[1]) {
      return false;
    }
    
    // Filter by gender
    if (filters.gender.length > 0 && !filters.gender.includes(user.gender)) {
      return false;
    }
    
    // Filter by location
    if (filters.location && !user.location.toLowerCase().includes(filters.location.toLowerCase())) {
      return false;
    }
    
    // Filter by interests
    if (filters.interests.length > 0) {
      if (!user.interests) return false;
      
      const hasMatchingInterest = filters.interests.some(interest => 
        user.interests?.includes(interest)
      );
      
      if (!hasMatchingInterest) return false;
    }
    
    return true;
  });

  return (
    <div>
      {/* Discover Header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <h1 className="text-3xl font-bold text-neutral-900">Découvrir</h1>
          <div className="mt-4 md:mt-0 flex flex-wrap gap-2">
            <Button 
              variant="outline" 
              onClick={toggleFilter}
              className="flex items-center"
            >
              <Filter className="mr-2 h-4 w-4" /> Filtres
            </Button>
            <Select defaultValue="recent">
              <SelectTrigger className="min-w-[180px]">
                <div className="flex items-center">
                  <SortDesc className="mr-2 h-4 w-4" />
                  <span>Trier par:</span>
                </div>
                <SelectValue placeholder="Récent" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Récent</SelectItem>
                <SelectItem value="distance">Distance</SelectItem>
                <SelectItem value="age">Âge</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Filter drawer */}
        {showFilters && (
          <div className="bg-white p-6 rounded-xl shadow-sm mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Filtres</h3>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={toggleFilter}
              >
                <X className="h-5 w-5 text-neutral-500" />
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <Label className="block text-sm font-medium text-neutral-700 mb-2">Âge ({filters.ageRange[0]} - {filters.ageRange[1]})</Label>
                <Slider 
                  value={[filters.ageRange[0], filters.ageRange[1]]} 
                  min={18} 
                  max={99} 
                  step={1}
                  onValueChange={(value) => {
                    setFilters({...filters, ageRange: [value[0], value[1]]});
                  }}
                  className="mt-6"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-neutral-700 mb-2">Distance</Label>
                <Select 
                  value={filters.distance}
                  onValueChange={(value) => setFilters({...filters, distance: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez une distance" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 km</SelectItem>
                    <SelectItem value="10">10 km</SelectItem>
                    <SelectItem value="25">25 km</SelectItem>
                    <SelectItem value="50">50 km</SelectItem>
                    <SelectItem value="100">100 km</SelectItem>
                    <SelectItem value="all">Partout</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="block text-sm font-medium text-neutral-700 mb-1">Je recherche</Label>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center">
                    <Checkbox 
                      id="filter-men" 
                      checked={filters.gender.includes("Homme")}
                      onCheckedChange={() => toggleGender("Homme")}
                    />
                    <Label htmlFor="filter-men" className="ml-2 text-sm">Hommes</Label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox 
                      id="filter-women" 
                      checked={filters.gender.includes("Femme")}
                      onCheckedChange={() => toggleGender("Femme")}
                    />
                    <Label htmlFor="filter-women" className="ml-2 text-sm">Femmes</Label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox 
                      id="filter-nonbinary" 
                      checked={filters.gender.includes("Non-binaire")}
                      onCheckedChange={() => toggleGender("Non-binaire")}
                    />
                    <Label htmlFor="filter-nonbinary" className="ml-2 text-sm">Non-binaire</Label>
                  </div>
                </div>
              </div>
              <div className="md:col-span-2 lg:col-span-3">
                <Label className="block text-sm font-medium text-neutral-700 mb-2">Intérêts</Label>
                <div className="flex flex-wrap gap-2">
                  {interestOptions.map((interest) => (
                    <InterestTag
                      key={interest}
                      interest={interest}
                      selected={filters.interests.includes(interest)}
                      onSelect={() => toggleInterest(interest)}
                    />
                  ))}
                </div>
                <p className="text-sm text-neutral-500 mt-2">
                  Sélectionnez jusqu'à 8 intérêts ({filters.interests.length}/8)
                </p>
              </div>
              <div className="md:col-span-2 lg:col-span-3">
                <Label className="block text-sm font-medium text-neutral-700 mb-2">Localisation</Label>
                <div className="flex items-center w-full relative">
                  <Search className="absolute left-3 h-4 w-4 text-neutral-400" />
                  <Input
                    className="pl-10"
                    placeholder="Ville, Pays..."
                    value={filters.location}
                    onChange={(e) => setFilters({...filters, location: e.target.value})}
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end mt-6 space-x-4">
              <Button variant="outline" onClick={handleResetFilters}>
                Réinitialiser
              </Button>
              <Button onClick={handleApplyFilters}>
                Appliquer
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Profile Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div 
              key={i} 
              className="bg-white rounded-xl shadow-sm overflow-hidden animate-pulse h-96"
            >
              <div className="bg-neutral-200 h-3/4"></div>
              <div className="p-4">
                <div className="h-4 bg-neutral-200 rounded mb-3"></div>
                <div className="h-3 bg-neutral-200 rounded mb-4 w-1/2"></div>
                <div className="flex space-x-2 mb-3">
                  <div className="h-6 bg-neutral-200 rounded w-16"></div>
                  <div className="h-6 bg-neutral-200 rounded w-20"></div>
                  <div className="h-6 bg-neutral-200 rounded w-14"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <>
          {filteredUsers && filteredUsers.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredUsers.map((user) => (
                <ProfileCard 
                  key={user.id}
                  id={user.id}
                  name={user.fullName.split(' ')[0]}
                  age={getAge(user.birthDate)}
                  location={user.location}
                  photo={user.profilePicture || ''}
                  interests={user.interests || []}
                  bio={user.bio}
                  isOnline={user.isOnline}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-4xl mb-4">😢</div>
              <h3 className="text-xl font-semibold mb-2">Aucun profil trouvé</h3>
              <p className="text-neutral-600">
                Essayez d'ajuster vos filtres pour voir plus de profils
              </p>
              <Button onClick={handleResetFilters} className="mt-4">
                Réinitialiser les filtres
              </Button>
            </div>
          )}
        </>
      )}

      {filteredUsers && filteredUsers.length > 0 && (
        <div className="flex justify-center mt-8">
          <Button variant="outline">
            Voir plus de profils
          </Button>
        </div>
      )}
    </div>
  );
};

export default Discover;
