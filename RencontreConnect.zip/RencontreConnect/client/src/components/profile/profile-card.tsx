import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle, Heart } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface ProfileCardProps {
  id?: number;
  name: string;
  age: number;
  location: string;
  photo: string;
  interests: string[];
  bio?: string;
  isOnline?: boolean;
}

const ProfileCard = ({ 
  id,
  name,
  age,
  location,
  photo,
  interests,
  bio,
  isOnline = false
}: ProfileCardProps) => {
  const [isLiked, setIsLiked] = useState(false);
  const { toast } = useToast();

  const handleLike = async () => {
    try {
      // Mock user ID - in a real application, would come from auth context
      const currentUserId = 1; 
      
      if (!id) {
        toast({
          title: "Erreur",
          description: "Impossible de liker ce profil",
          variant: "destructive",
        });
        return;
      }

      if (!isLiked) {
        const likeData = {
          fromUserId: currentUserId,
          toUserId: id
        };

        const response = await apiRequest('POST', '/api/likes', likeData);
        const result = await response.json();

        setIsLiked(true);

        if (result.isMatch) {
          toast({
            title: "Match!",
            description: `Vous avez un nouveau match avec ${name}!`,
            variant: "default",
          });
          // Invalidate matches query to refresh matches list
          queryClient.invalidateQueries({ queryKey: [`/api/matches/${currentUserId}`] });
        } else {
          toast({
            title: "J'aime envoyé",
            description: `Vous avez aimé le profil de ${name}`,
            variant: "default",
          });
        }
      } else {
        // Unlike functionality would go here in a complete implementation
        setIsLiked(false);
        toast({
          title: "J'aime retiré",
          description: `Vous n'aimez plus le profil de ${name}`,
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Error liking profile:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue. Veuillez réessayer.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="profile-card bg-white rounded-xl shadow-sm overflow-hidden transition-all hover:shadow-md hover:-translate-y-1">
      <div className="relative pb-[120%]">
        <img 
          src={photo} 
          alt={`${name}, ${age}`} 
          className="absolute h-full w-full object-cover object-center"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
          <div className="flex items-center">
            <h3 className="text-white font-semibold text-xl">{name}, {age}</h3>
            {isOnline && (
              <div className="ml-2 h-2 w-2 rounded-full bg-green-500"></div>
            )}
          </div>
          <p className="text-white/90 text-sm">{location}</p>
        </div>
      </div>
      <div className="p-4">
        {bio && (
          <p className="text-neutral-600 text-sm mb-3 line-clamp-2">{bio}</p>
        )}
        <div className="flex flex-wrap gap-2 mb-3">
          {interests.slice(0, 3).map((interest, index) => (
            <span key={index} className="px-3 py-1 bg-neutral-100 text-neutral-800 rounded-full text-xs">
              {interest}
            </span>
          ))}
          {interests.length > 3 && (
            <span className="px-3 py-1 bg-neutral-100 text-neutral-800 rounded-full text-xs">
              +{interests.length - 3}
            </span>
          )}
        </div>
        <div className="flex justify-between mt-2">
          <Link href={id ? `/messages?userId=${id}` : "#"}>
            <Button variant="secondary" className="w-full mr-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800">
              <MessageCircle className="mr-1 h-4 w-4" /> Message
            </Button>
          </Link>
          <Button 
            variant="secondary" 
            className={`w-full ${isLiked ? 'bg-primary/20 hover:bg-primary/30 text-primary' : 'bg-primary/10 hover:bg-primary/20 text-primary'}`}
            onClick={handleLike}
          >
            <Heart className={`mr-1 h-4 w-4 ${isLiked ? 'fill-primary' : ''}`} /> J'aime
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProfileCard;
