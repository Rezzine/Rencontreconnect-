interface InterestTagProps {
  interest: string;
  selected?: boolean;
  onSelect?: () => void;
}

const InterestTag = ({ interest, selected = false, onSelect }: InterestTagProps) => {
  return (
    <span 
      className={`px-3 py-1 rounded-full text-sm cursor-pointer transition-colors ${
        selected 
          ? 'bg-primary/10 text-primary' 
          : 'bg-neutral-100 text-neutral-800 hover:bg-primary/10 hover:text-primary'
      }`}
      onClick={onSelect}
    >
      {interest}
    </span>
  );
};

export default InterestTag;
