import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

interface AdBannerProps {
  position?: 'top' | 'bottom' | 'sidebar';
  size?: 'small' | 'medium' | 'large';
}

// Ad content data 
const adContents = [
  {
    id: 1,
    title: "Premium Dating Events",
    description: "Join exclusive meetups in your city",
    cta: "Learn More",
    imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    url: "/premium",
    backgroundColor: "#f9fafb",
    textColor: "#111827",
    pricePerImpression: 0.001, // €0.001 per impression
    pricePerClick: 0.05, // €0.05 per click
  },
  {
    id: 2,
    title: "Dating Coach Services",
    description: "Get personalized advice from experts",
    cta: "Book Now",
    imageUrl: "https://images.unsplash.com/photo-1543269865-cbf427effbad?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    url: "/premium",
    backgroundColor: "#eff6ff",
    textColor: "#1e40af",
    pricePerImpression: 0.002, // €0.002 per impression
    pricePerClick: 0.08, // €0.08 per click
  },
  {
    id: 3,
    title: "Relationship Workshops",
    description: "Build better connections with our workshops",
    cta: "Register",
    imageUrl: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    url: "/premium",
    backgroundColor: "#f0fdf4",
    textColor: "#166534",
    pricePerImpression: 0.0015, // €0.0015 per impression
    pricePerClick: 0.07, // €0.07 per click
  }
];

export function AdBanner({ position = 'top', size = 'medium' }: AdBannerProps) {
  const [dismissed, setDismissed] = useState(false);
  const [currentAdIndex, setCurrentAdIndex] = useState(0);
  const [impressionLogged, setImpressionLogged] = useState(false);
  
  // Select random ad on mount
  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * adContents.length);
    setCurrentAdIndex(randomIndex);
  }, []);
  
  // Log impression when ad is shown
  useEffect(() => {
    if (!dismissed && !impressionLogged) {
      // In a real app, you would log this to your analytics or ad server
      console.log(`Ad impression logged: ${adContents[currentAdIndex].id}`);
      setImpressionLogged(true);
      
      // Simulate ad revenue
      fetch('/api/ads/impression', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          adId: adContents[currentAdIndex].id,
          type: 'impression'
        })
      }).catch(err => console.error('Failed to log impression:', err));
    }
  }, [dismissed, currentAdIndex, impressionLogged]);
  
  if (dismissed) return null;
  
  const currentAd = adContents[currentAdIndex];
  
  const handleClick = () => {
    // Log click event
    fetch('/api/ads/click', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        adId: currentAd.id,
        type: 'click'
      })
    }).catch(err => console.error('Failed to log click:', err));
    
    // Open the destination URL
    window.location.href = currentAd.url;
  };
  
  const getSizeClasses = () => {
    switch(size) {
      case 'small':
        return 'h-16 text-xs';
      case 'large':
        return 'h-48 md:h-64 text-base';
      case 'medium':
      default:
        return 'h-32 text-sm';
    }
  };
  
  const getPositionClasses = () => {
    switch(position) {
      case 'bottom':
        return 'bottom-0 left-0 right-0';
      case 'sidebar':
        return 'right-0 top-1/4 w-64';
      case 'top':
      default:
        return 'top-0 left-0 right-0';
    }
  };
  
  return (
    <Card 
      className={`overflow-hidden relative w-full ${getSizeClasses()} ${position === 'sidebar' ? '' : 'mx-auto'} my-4 border`}
      style={{ 
        backgroundColor: currentAd.backgroundColor,
        color: currentAd.textColor,
      }}
    >
      <Button 
        variant="ghost" 
        size="icon"
        className="absolute top-1 right-1 h-6 w-6 bg-white/70 hover:bg-white z-10"
        onClick={() => setDismissed(true)}
      >
        <X className="h-3 w-3" />
      </Button>
      
      <div className="flex h-full">
        <div 
          className="hidden md:block w-1/3 bg-cover bg-center" 
          style={{ backgroundImage: `url(${currentAd.imageUrl})` }}
        />
        <CardContent className="p-4 flex flex-col justify-between w-full md:w-2/3">
          <div>
            <div className="text-xs uppercase font-light mb-1">Sponsored</div>
            <h3 className="font-semibold">{currentAd.title}</h3>
            <p className="text-sm mt-1 line-clamp-2">{currentAd.description}</p>
          </div>
          <Button 
            variant="outline" 
            className="mt-2 self-start" 
            size="sm"
            onClick={handleClick}
            style={{ 
              borderColor: currentAd.textColor, 
              color: currentAd.textColor 
            }}
          >
            {currentAd.cta}
          </Button>
        </CardContent>
      </div>
    </Card>
  );
}