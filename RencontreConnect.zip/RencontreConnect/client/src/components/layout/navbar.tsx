import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Menu, LogOut, User, Settings } from "lucide-react";

// Mocked auth state - in a real app, this would come from auth context
const mockIsAuthenticated = false;
const mockUser = {
  id: 1,
  fullName: "Sophie Martin",
  profilePicture: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80"
};

const Navbar = () => {
  const [location] = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(mockIsAuthenticated);
  const [user, setUser] = useState(mockUser);

  const handleLogout = () => {
    // In a real app, this would call an API and clear auth state
    setIsAuthenticated(false);
  };

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/">
              <a className="flex-shrink-0 flex items-center">
                <span className="text-primary font-bold text-2xl">Rendez-Vous</span>
              </a>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <NavLink href="/" current={location === "/"}>
                Accueil
              </NavLink>
              <NavLink href="/discover" current={location === "/discover"}>
                Découvrir
              </NavLink>
              <NavLink href="/matches" current={location === "/matches"}>
                Matches
              </NavLink>
              <NavLink href="/messages" current={location === "/messages"}>
                Messages
              </NavLink>
              <NavLink href="/premium" current={location === "/premium"}>
                Premium
              </NavLink>
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="hidden md:flex items-center space-x-4">
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger className="focus:outline-none">
                    <div className="flex items-center">
                      <img 
                        src={user.profilePicture} 
                        alt="Profile" 
                        className="h-8 w-8 rounded-full object-cover border border-neutral-200"
                      />
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href="/profile/edit">
                        <a className="flex items-center cursor-pointer">
                          <User className="mr-2 h-4 w-4" />
                          <span>Profil</span>
                        </a>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/settings">
                        <a className="flex items-center cursor-pointer">
                          <Settings className="mr-2 h-4 w-4" />
                          <span>Paramètres</span>
                        </a>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="flex items-center cursor-pointer"
                      onClick={handleLogout}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Déconnexion</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <>
                  <Link href="/login">
                    <Button variant="outline" className="text-primary border-primary">
                      Connexion
                    </Button>
                  </Link>
                  <Link href="/profile/create">
                    <Button>
                      Inscription
                    </Button>
                  </Link>
                </>
              )}
            </div>
            
            {/* Mobile menu button */}
            <div className="flex md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-neutral-600 hover:text-neutral-800 hover:bg-neutral-100 ml-4"
                  >
                    <Menu className="h-6 w-6" />
                    <span className="sr-only">Open menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col h-full py-4">
                    <div className="px-4 mb-8">
                      <Link href="/">
                        <a className="text-primary font-bold text-2xl">Rendez-Vous</a>
                      </Link>
                    </div>
                    
                    {isAuthenticated && (
                      <div className="px-4 py-3 border-b border-neutral-200 mb-4">
                        <div className="flex items-center">
                          <div className="flex-shrink-0">
                            <img 
                              src={user.profilePicture} 
                              alt="Profile" 
                              className="h-10 w-10 rounded-full object-cover"
                            />
                          </div>
                          <div className="ml-3">
                            <div className="text-base font-medium text-neutral-800">{user.fullName}</div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <nav className="flex-1 px-2 space-y-1">
                      <MobileNavLink href="/" current={location === "/"}>
                        Accueil
                      </MobileNavLink>
                      <MobileNavLink href="/discover" current={location === "/discover"}>
                        Découvrir
                      </MobileNavLink>
                      <MobileNavLink href="/matches" current={location === "/matches"}>
                        Matches
                      </MobileNavLink>
                      <MobileNavLink href="/messages" current={location === "/messages"}>
                        Messages
                      </MobileNavLink>
                      <MobileNavLink href="/premium" current={location === "/premium"}>
                        Premium
                      </MobileNavLink>
                    </nav>
                    
                    <div className="px-4 py-4 border-t border-neutral-200">
                      {isAuthenticated ? (
                        <div className="space-y-1">
                          <Link href="/profile/edit">
                            <a className="block px-3 py-2 rounded-md text-base font-medium text-neutral-600 hover:text-neutral-800 hover:bg-neutral-100">
                              Votre profil
                            </a>
                          </Link>
                          <Link href="/settings">
                            <a className="block px-3 py-2 rounded-md text-base font-medium text-neutral-600 hover:text-neutral-800 hover:bg-neutral-100">
                              Paramètres
                            </a>
                          </Link>
                          <button 
                            onClick={handleLogout}
                            className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-neutral-600 hover:text-neutral-800 hover:bg-neutral-100"
                          >
                            Déconnexion
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-col space-y-2">
                          <Link href="/login">
                            <Button variant="outline" className="w-full text-primary border-primary">
                              Connexion
                            </Button>
                          </Link>
                          <Link href="/profile/create">
                            <Button className="w-full">
                              Inscription
                            </Button>
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

interface NavLinkProps {
  href: string;
  current: boolean;
  children: React.ReactNode;
}

const NavLink = ({ href, current, children }: NavLinkProps) => {
  return (
    <Link href={href}>
      <a className={`${
        current 
          ? 'border-primary text-neutral-800 border-b-2' 
          : 'border-transparent text-neutral-600 hover:text-neutral-800 hover:border-neutral-400 border-b-2'
        } px-1 pt-1 font-medium text-sm`}
      >
        {children}
      </a>
    </Link>
  );
};

const MobileNavLink = ({ href, current, children }: NavLinkProps) => {
  return (
    <Link href={href}>
      <a className={`${
        current 
          ? 'bg-primary text-white' 
          : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-800'
        } block px-3 py-2 rounded-md text-base font-medium`}
      >
        {children}
      </a>
    </Link>
  );
};

export default Navbar;
