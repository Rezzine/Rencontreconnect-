import { Link } from "wouter";
import { Facebook, Instagram, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-white border-t border-neutral-200 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:justify-between">
          <div className="mb-8 md:mb-0">
            <Link href="/">
              <a className="flex items-center">
                <span className="text-primary font-bold text-2xl">Rendez-Vous</span>
              </a>
            </Link>
            <p className="mt-2 text-sm text-neutral-600 max-w-md">
              Découvrez des connexions authentiques et significatives. Notre plateforme vous aide à trouver des personnes partageant vos intérêts.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            <div>
              <h3 className="text-sm font-semibold text-neutral-900 tracking-wider uppercase mb-4">
                À propos
              </h3>
              <ul className="space-y-3">
                <li>
                  <Link href="/about">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Comment ça marche
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="/testimonials">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Témoignages
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="/careers">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Carrières
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="/investors">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Investisseurs
                    </a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-neutral-900 tracking-wider uppercase mb-4">
                Support
              </h3>
              <ul className="space-y-3">
                <li>
                  <Link href="/help">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Centre d'aide
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="/safety">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Sécurité
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="/community">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Communauté
                    </a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-neutral-900 tracking-wider uppercase mb-4">
                Légal
              </h3>
              <ul className="space-y-3">
                <li>
                  <Link href="/privacy">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Confidentialité
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="/terms">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Conditions
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="/cookies">
                    <a className="text-sm text-neutral-600 hover:text-neutral-900">
                      Politique des cookies
                    </a>
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-neutral-200 pt-8 md:flex md:items-center md:justify-between">
          <div className="flex space-x-6 md:order-2">
            <a href="https://facebook.com" className="text-neutral-400 hover:text-neutral-600" target="_blank" rel="noopener noreferrer">
              <span className="sr-only">Facebook</span>
              <Facebook className="h-5 w-5" />
            </a>
            <a href="https://instagram.com" className="text-neutral-400 hover:text-neutral-600" target="_blank" rel="noopener noreferrer">
              <span className="sr-only">Instagram</span>
              <Instagram className="h-5 w-5" />
            </a>
            <a href="https://twitter.com" className="text-neutral-400 hover:text-neutral-600" target="_blank" rel="noopener noreferrer">
              <span className="sr-only">Twitter</span>
              <Twitter className="h-5 w-5" />
            </a>
          </div>
          <p className="mt-8 text-sm text-neutral-500 md:mt-0 md:order-1">
            &copy; {new Date().getFullYear()} Rendez-Vous. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
