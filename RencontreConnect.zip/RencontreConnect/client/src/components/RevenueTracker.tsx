import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowRight, 
  LineChart, 
  RefreshCw, 
  Wallet, 
  BarChart4, 
  Share2, 
  DollarSign 
} from "lucide-react";

export const RevenueTracker = () => {
  const { data, isLoading } = useQuery({
    queryKey: ["/api/stats/revenue"],
    refetchInterval: 5000 // Rafraîchir toutes les 5 secondes
  });
  
  const { data: adRevenue, isLoading: isLoadingAdRevenue } = useQuery({
    queryKey: ["/api/ads/revenue"],
    refetchInterval: 5000
  });
  
  const { data: referralRevenue, isLoading: isLoadingReferralRevenue } = useQuery({
    queryKey: ["/api/referral/revenue"],
    refetchInterval: 5000
  });
  
  const [activeTab, setActiveTab] = useState("overview");
  
  const { data: transactions } = useQuery({
    queryKey: ["/api/transactions"],
    refetchInterval: 10000
  });

  if (isLoading || isLoadingAdRevenue || isLoadingReferralRevenue) return <div>Chargement...</div>;

  // Calculer les revenus totaux
  const subscriptionRevenue = data?.revenue || 0;
  const advertisingRevenue = adRevenue?.revenue || 0;
  const referralsRevenue = referralRevenue?.revenue || 0;
  const totalRevenue = subscriptionRevenue + advertisingRevenue + referralsRevenue;
  
  // Calculer la projection hebdomadaire (revenu journalier × 7)
  const weeklyProjection = totalRevenue * 7;
  // Calculer le montant mensuel
  const monthlyProjection = totalRevenue * 30;
  
  // La date du prochain transfert (exemple: tous les 1er du mois)
  const today = new Date();
  const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
  const daysToNextTransfer = Math.ceil((nextMonth.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  return (
    <Card className="w-full shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl">Tableau de bord financier</CardTitle>
      </CardHeader>
      
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 mx-4">
          <TabsTrigger value="overview">Aperçu</TabsTrigger>
          <TabsTrigger value="wise">Wise Transfer</TabsTrigger>
          <TabsTrigger value="projections">Projections</TabsTrigger>
        </TabsList>
        
        <CardContent className="pt-4">
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Revenus totaux</h3>
                  <Wallet className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-2xl font-bold mt-2">{totalRevenue.toFixed(2)} {data?.currency}</p>
                <div className="text-sm text-muted-foreground mt-2">
                  {data?.revenuePerUser} {data?.currency} par utilisateur
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Projection mensuelle</h3>
                  <LineChart className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-2xl font-bold mt-2 text-green-600">{monthlyProjection.toFixed(2)} {data?.currency}</p>
                <div className="text-sm text-muted-foreground mt-2">
                  Basé sur les revenus actuels
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Abonnements</h3>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-xl font-bold mt-2 text-blue-600">{subscriptionRevenue.toFixed(2)} {data?.currency}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {((subscriptionRevenue / totalRevenue) * 100).toFixed(1)}% du total
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Publicités</h3>
                  <BarChart4 className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-xl font-bold mt-2 text-purple-600">{advertisingRevenue.toFixed(2)} {data?.currency}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {((advertisingRevenue / totalRevenue) * 100).toFixed(1)}% du total
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Parrainages</h3>
                  <Share2 className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-xl font-bold mt-2 text-green-600">{referralsRevenue.toFixed(2)} {data?.currency}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {((referralsRevenue / totalRevenue) * 100).toFixed(1)}% du total
                </p>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-medium mb-2">Augmentez vos revenus</h3>
              <p className="text-sm mb-3">Invitez vos amis et gagnez jusqu'à 500€ avec notre programme de parrainage!</p>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" className="bg-[#1DA1F2] text-white hover:bg-[#1a8cd8]"
                  onClick={() => window.open(`https://twitter.com/intent/tweet?text=Rejoignez-moi sur cette super app!&url=${window.location.href}`)}>
                  Twitter
                </Button>
                <Button size="sm" variant="outline" className="bg-[#4267B2] text-white hover:bg-[#365899]"
                  onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${window.location.href}`)}>
                  Facebook
                </Button>
                <Button size="sm" variant="outline" className="bg-[#25D366] text-white hover:bg-[#128C7E]"
                  onClick={() => window.open(`https://api.whatsapp.com/send?text=Rejoignez-moi sur cette super app! ${window.location.href}`)}>
                  WhatsApp
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="wise" className="space-y-4">
            <div className="bg-sky-50 p-5 rounded-lg border border-sky-100">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-lg">Transfert vers Wise</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Vos revenus sont transférés automatiquement vers votre compte Wise le 1er de chaque mois.
                  </p>
                </div>
                <div className="bg-white p-2 rounded-full shadow-sm">
                  <img src="https://wise.com/public-resources/assets/logos/wise/brand_logo.svg" alt="Wise Logo" className="h-8 w-8" />
                </div>
              </div>
              
              <div className="mt-4 grid gap-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Prochain transfert dans:</span>
                  <span className="font-semibold">{daysToNextTransfer} jours</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Montant estimé:</span>
                  <span className="font-semibold">{monthlyProjection} {data?.currency}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Frais de transfert:</span>
                  <span className="font-semibold text-green-600">0.5%</span>
                </div>
              </div>
              
              <div className="mt-4">
                <Button className="w-full justify-between" disabled>
                  <span>Configurer transfert automatique</span>
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
                <p className="text-xs text-center mt-2 text-muted-foreground">
                  Ouvrez d'abord un compte Wise pour activer cette fonctionnalité
                </p>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg border shadow-sm">
              <h3 className="font-medium mb-3">Historique des transferts</h3>
              <div className="text-center py-6 text-muted-foreground">
                <p>Aucun transfert effectué pour le moment</p>
                <p className="text-sm mt-1">Les transferts apparaîtront ici une fois configurés</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="projections" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Journalier</h3>
                  <RefreshCw className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-2xl font-bold mt-2">{totalRevenue.toFixed(2)} {data?.currency}</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Hebdomadaire</h3>
                  <RefreshCw className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-2xl font-bold mt-2">{weeklyProjection.toFixed(2)} {data?.currency}</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-muted-foreground">Mensuel</h3>
                  <RefreshCw className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-2xl font-bold mt-2">{monthlyProjection.toFixed(2)} {data?.currency}</p>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg border shadow-sm mb-4">
              <h3 className="font-medium mb-3">Répartition annuelle estimée</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">Abonnements:</span>
                  <span className="font-semibold">{(subscriptionRevenue * 365).toFixed(2)} {data?.currency}</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">Publicités:</span>
                  <span className="font-semibold">{(advertisingRevenue * 365).toFixed(2)} {data?.currency}</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">Parrainages:</span>
                  <span className="font-semibold">{(referralsRevenue * 365).toFixed(2)} {data?.currency}</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">Total:</span>
                  <span className="font-semibold text-green-600">{(totalRevenue * 365).toFixed(2)} {data?.currency}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg border shadow-sm">
              <h3 className="font-medium mb-3">Conseils pour augmenter vos revenus</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-800 rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">1</span>
                  <span>Optimisez les emplacements des publicités pour augmenter le taux de clics</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-800 rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">2</span>
                  <span>Lancez des promotions saisonnières pour les abonnements premium</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-800 rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">3</span>
                  <span>Élargissez votre programme de parrainage à travers les réseaux sociaux</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-800 rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">4</span>
                  <span>Ciblez le marché asiatique, en particulier la Chine, avec WeChat Pay</span>
                </li>
              </ul>
            </div>
          </TabsContent>
        </CardContent>
      </Tabs>
      
      <div className="text-xs text-center text-muted-foreground pb-2">
        Dernière mise à jour: {new Date(data?.lastUpdated).toLocaleString()}
      </div>
    </Card>
  );
};