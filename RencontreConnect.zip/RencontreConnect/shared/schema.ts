import { pgTable, text, serial, integer, boolean, timestamp, jsonb, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Ad content for the application
export const adContents = [
  {
    id: 1,
    title: "Premium Dating Events",
    description: "Join exclusive meetups in your city",
    cta: "Learn More",
    imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    url: "/premium",
    backgroundColor: "#f9fafb",
    textColor: "#111827",
    pricePerImpression: 0.001, // €0.001 per impression
    pricePerClick: 0.05, // €0.05 per click
  },
  {
    id: 2,
    title: "Dating Coach Services",
    description: "Get personalized advice from experts",
    cta: "Book Now",
    imageUrl: "https://images.unsplash.com/photo-1543269865-cbf427effbad?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    url: "/premium",
    backgroundColor: "#eff6ff",
    textColor: "#1e40af",
    pricePerImpression: 0.002, // €0.002 per impression
    pricePerClick: 0.08, // €0.08 per click
  },
  {
    id: 3,
    title: "Relationship Workshops",
    description: "Build better connections with our workshops",
    cta: "Register",
    imageUrl: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    url: "/premium",
    backgroundColor: "#f0fdf4",
    textColor: "#166534",
    pricePerImpression: 0.0015, // €0.0015 per impression
    pricePerClick: 0.07, // €0.07 per click
  }
];

// Referral program levels
export const referralRewards = [
  { level: 1, invites: 1, reward: 5 }, // €5 for 1 invite
  { level: 2, invites: 5, reward: 30 }, // €30 for 5 invites
  { level: 3, invites: 10, reward: 75 }, // €75 for 10 invites
  { level: 4, invites: 25, reward: 200 }, // €200 for 25 invites
  { level: 5, invites: 50, reward: 500 }, // €500 for 50 invites
];

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  birthDate: text("birth_date").notNull(),
  gender: text("gender").notNull(),
  interestedIn: text("interested_in").notNull(),
  location: text("location").notNull(),
  bio: text("bio"),
  profilePicture: text("profile_picture"),
  photos: jsonb("photos").$type<string[]>(),
  interests: jsonb("interests").$type<string[]>(),
  language: text("language").notNull(),
  country: text("country").notNull(),
  languages_spoken: jsonb("languages_spoken").$type<string[]>(),
  hideLocation: boolean("hide_location").default(false),
  hideOnlineStatus: boolean("hide_online_status").default(false),
  showInSearch: boolean("show_in_search").default(true),
  isOnline: boolean("is_online").default(false),
  lastActive: timestamp("last_active").defaultNow(),
  isPremium: boolean("is_premium").default(false),
  premiumUntil: timestamp("premium_until"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  isOnline: true,
  lastActive: true,
  isPremium: true,
  premiumUntil: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Likes schema (for matching)
export const likes = pgTable("likes", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").notNull().references(() => users.id),
  toUserId: integer("to_user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLikeSchema = createInsertSchema(likes).omit({
  id: true,
  createdAt: true,
});

export type InsertLike = z.infer<typeof insertLikeSchema>;
export type Like = typeof likes.$inferSelect;

// Matches schema (when two users like each other)
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  user1Id: integer("user1_id").notNull().references(() => users.id),
  user2Id: integer("user2_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
  createdAt: true,
});

export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;

// Messages schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  matchId: integer("match_id").notNull().references(() => matches.id),
  senderId: integer("sender_id").notNull().references(() => users.id),
  receiverId: integer("receiver_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  read: true,
  createdAt: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Subscription plans
export const subscriptionPlans = [
  { id: 'basic', name: 'Basic', price: 9.99, duration: 30, features: ['Unlimited likes', 'See who liked you'] },
  { id: 'premium', name: 'Premium', price: 19.99, duration: 30, features: ['Unlimited likes', 'See who liked you', 'Priority in search results', 'Advanced filters'] },
  { id: 'platinum', name: 'Platinum', price: 29.99, duration: 30, features: ['Unlimited likes', 'See who liked you', 'Priority in search results', 'Advanced filters', 'Read receipts', 'Incognito mode'] }
];

// Payment transactions
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  paypalOrderId: text("paypal_order_id").notNull(),
  amount: numeric("amount").notNull(),
  currency: text("currency").notNull(),
  status: text("status").notNull(), // 'pending', 'completed', 'failed'
  planId: text("plan_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

// Ad interactions schema
export const adInteractions = pgTable("ad_interactions", {
  id: serial("id").primaryKey(),
  adId: integer("ad_id").notNull(),
  userId: integer("user_id").references(() => users.id),
  type: text("type").notNull(), // 'impression', 'click'
  revenue: numeric("revenue").notNull(),
  currency: text("currency").notNull().default('EUR'),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAdInteractionSchema = createInsertSchema(adInteractions).omit({
  id: true,
  createdAt: true,
});

export type InsertAdInteraction = z.infer<typeof insertAdInteractionSchema>;
export type AdInteraction = typeof adInteractions.$inferSelect;

// Referral program
export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrer_id").notNull().references(() => users.id),
  referredId: integer("referred_id").notNull().references(() => users.id),
  code: text("code").notNull(),
  status: text("status").notNull().default('pending'), // 'pending', 'completed'
  reward: numeric("reward"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  status: true,
  createdAt: true,
  completedAt: true,
});

export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Referral = typeof referrals.$inferSelect;
