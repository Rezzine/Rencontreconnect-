import { 
  User, InsertUser, 
  Like, InsertLike, 
  Match, InsertMatch, 
  Message, InsertMessage, 
  Transaction, InsertTransaction,
  InsertAdInteraction, AdInteraction,
  InsertReferral, Referral
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  updateUserOnlineStatus(id: number, isOnline: boolean): Promise<User | undefined>;
  getUsers(filters?: any): Promise<User[]>;
  updateUserPremiumStatus(id: number, isPremium: boolean, premiumUntil: Date): Promise<User | undefined>;
  
  // Like methods
  createLike(like: InsertLike): Promise<Like>;
  getLikeByUsers(fromUserId: number, toUserId: number): Promise<Like | undefined>;
  getLikesByFromUser(fromUserId: number): Promise<Like[]>;
  getLikesByToUser(toUserId: number): Promise<Like[]>;
  
  // Match methods
  createMatch(match: InsertMatch): Promise<Match>;
  getMatchesByUser(userId: number): Promise<Match[]>;
  getMatch(matchId: number): Promise<Match | undefined>;
  
  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByMatch(matchId: number): Promise<Message[]>;
  markMessagesAsRead(messageIds: number[]): Promise<void>;
  
  // Payment methods
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionByPayPalOrderId(paypalOrderId: string): Promise<Transaction | undefined>;
  getTransactionsByUser(userId: number): Promise<Transaction[]>;
  updateTransactionStatus(id: number, status: string, completedAt?: Date): Promise<Transaction | undefined>;
  
  // Revenue methods
  addRevenue(amount: number): Promise<number>;
  getRevenue(): Promise<{total: number, perUser: number}>;
  
  // Advertisement methods
  createAdInteraction(interaction: InsertAdInteraction): Promise<AdInteraction>;
  getAdInteractions(filters?: { adId?: number, userId?: number, type?: string }): Promise<AdInteraction[]>;
  getAdRevenue(): Promise<number>;
  
  // Referral methods
  createReferral(referral: InsertReferral): Promise<Referral>;
  updateReferralStatus(id: number, status: string, reward: number, completedAt?: Date): Promise<Referral | undefined>;
  getReferralsByUser(userId: number): Promise<Referral[]>;
  getReferralRevenue(): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private likes: Map<number, Like>;
  private matches: Map<number, Match>;
  private messages: Map<number, Message>;
  private transactions: Map<number, Transaction>;
  private adInteractions: Map<number, AdInteraction>;
  private referrals: Map<number, Referral>;
  
  private userId: number;
  private likeId: number;
  private matchId: number;
  private messageId: number;
  private transactionId: number;
  private adInteractionId: number;
  private referralId: number;
  private revenue: number;
  private adRevenue: number;
  private referralRevenue: number;

  constructor() {
    this.users = new Map();
    this.likes = new Map();
    this.matches = new Map();
    this.messages = new Map();
    this.transactions = new Map();
    this.adInteractions = new Map();
    this.referrals = new Map();
    
    this.revenue = 0;
    this.adRevenue = 0;
    this.referralRevenue = 0;
    
    this.userId = 1;
    this.likeId = 1;
    this.matchId = 1;
    this.messageId = 1;
    this.transactionId = 1;
    this.adInteractionId = 1;
    this.referralId = 1;
    
    // Add some initial users for testing
    this.createInitialUsers();
  }
  
  private async createInitialUsers() {
    const initialUsers: InsertUser[] = [
      {
        username: "camille",
        password: "password123",
        fullName: "Camille Dubois",
        birthDate: "1995-05-15",
        gender: "Femme",
        interestedIn: "Hommes",
        location: "Paris, France",
        bio: "Yogiste passionnée, amoureuse de l'art et des voyages.",
        profilePicture: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
        photos: [
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
          "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80"
        ],
        interests: ["Yoga", "Voyages", "Art"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true
      },
      {
        username: "thomas",
        password: "password123",
        fullName: "Thomas Martin",
        birthDate: "1991-08-22",
        gender: "Homme",
        interestedIn: "Femmes",
        location: "Lyon, France",
        bio: "Musicien et sportif, j'adore découvrir de nouveaux endroits et expériences.",
        profilePicture: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
        photos: [
          "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
          "https://images.unsplash.com/photo-1488161628813-04466f872be2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80"
        ],
        interests: ["Musique", "Sport", "Cinéma"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true
      },
      {
        username: "julie",
        password: "password123",
        fullName: "Julie Petit",
        birthDate: "1997-03-10",
        gender: "Femme",
        interestedIn: "Hommes",
        location: "Bordeaux, France",
        bio: "Professeur de yoga et passionnée de lecture. J'adore les animaux et la nature.",
        profilePicture: "https://images.unsplash.com/photo-1534751516642-a1af1ef26a56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=389&q=80",
        photos: [
          "https://images.unsplash.com/photo-1534751516642-a1af1ef26a56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=389&q=80"
        ],
        interests: ["Lecture", "Cuisine", "Randonnée"],
        hideLocation: false,
        hideOnlineStatus: true,
        showInSearch: true
      },
      {
        username: "marc",
        password: "password123",
        fullName: "Marc Dupont",
        birthDate: "1993-11-05",
        gender: "Homme",
        interestedIn: "Femmes",
        location: "Marseille, France",
        bio: "Photographe et amateur de sports extrêmes. À la recherche de nouvelles perspectives et d'aventures.",
        profilePicture: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
        photos: [
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80"
        ],
        interests: ["Photographie", "Sport", "Voyages"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true
      },
      {
        username: "laura",
        password: "password123",
        fullName: "Laura Blanc",
        birthDate: "1998-07-20",
        gender: "Femme",
        interestedIn: "Hommes",
        location: "Paris, France",
        bio: "Graphiste passionnée, amoureuse de la vie et toujours prête pour de nouvelles aventures.",
        profilePicture: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=388&q=80",
        photos: [
          "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=388&q=80"
        ],
        interests: ["Design", "Voyages", "Cinéma"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true
      },
      {
        username: "nicolas",
        password: "password123",
        fullName: "Nicolas Leroy",
        birthDate: "1992-02-15",
        gender: "Homme",
        interestedIn: "Femmes",
        location: "Paris, France",
        bio: "Ingénieur et musicien à mes heures perdues. J'aime les randonnées et découvrir de nouveaux restaurants.",
        profilePicture: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
        photos: [
          "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80"
        ],
        interests: ["Musique", "Randonnée", "Gastronomie"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true
      },
      {
        username: "emma",
        password: "password123",
        fullName: "Emma Garcia",
        birthDate: "1996-05-12",
        gender: "Femme",
        interestedIn: "Hommes",
        location: "Paris, France",
        bio: "Professeur de yoga et amatrice de lecture. J'adore les animaux et la nature.",
        profilePicture: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=461&q=80",
        photos: [
          "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=461&q=80"
        ],
        interests: ["Yoga", "Lecture", "Nature"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true
      },
      {
        username: "julien",
        password: "password123",
        fullName: "Julien Fournier",
        birthDate: "1994-09-28",
        gender: "Homme",
        interestedIn: "Femmes",
        location: "Versailles, France",
        bio: "Photographe et amateur de sports extrêmes. À la recherche de nouvelles perspectives et d'aventures.",
        profilePicture: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1148&q=80",
        photos: [
          "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1148&q=80"
        ],
        interests: ["Photographie", "Sports", "Aventure"],
        hideLocation: false,
        hideOnlineStatus: false,
        showInSearch: true
      }
    ];
    
    initialUsers.forEach(user => {
      this.createUser(user);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = {
      ...userData,
      id,
      isOnline: false,
      lastActive: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserOnlineStatus(id: number, isOnline: boolean): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { 
      ...user, 
      isOnline, 
      lastActive: isOnline ? user.lastActive : new Date()
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getUsers(filters?: any): Promise<User[]> {
    let users = Array.from(this.users.values());
    
    if (filters) {
      if (filters.gender) {
        users = users.filter(user => user.gender === filters.gender);
      }
      
      if (filters.interestedIn) {
        users = users.filter(user => user.interestedIn === filters.interestedIn);
      }
      
      if (filters.minAge && filters.maxAge) {
        const minDate = new Date();
        minDate.setFullYear(minDate.getFullYear() - parseInt(filters.maxAge));
        
        const maxDate = new Date();
        maxDate.setFullYear(maxDate.getFullYear() - parseInt(filters.minAge));
        
        users = users.filter(user => {
          const birthDate = new Date(user.birthDate);
          return birthDate >= minDate && birthDate <= maxDate;
        });
      }
      
      if (filters.interests && filters.interests.length > 0) {
        const interestsArray = Array.isArray(filters.interests) 
          ? filters.interests 
          : [filters.interests];
          
        users = users.filter(user => 
          user.interests && interestsArray.some(interest => 
            user.interests.includes(interest)
          )
        );
      }
      
      if (filters.location) {
        users = users.filter(user => 
          user.location.toLowerCase().includes(filters.location.toLowerCase())
        );
      }
      
      if (filters.showInSearch !== undefined) {
        users = users.filter(user => 
          user.showInSearch === (filters.showInSearch === 'true')
        );
      }
    }
    
    return users;
  }

  // Like methods
  async createLike(likeData: InsertLike): Promise<Like> {
    const id = this.likeId++;
    const now = new Date();
    const like: Like = {
      ...likeData,
      id,
      createdAt: now
    };
    this.likes.set(id, like);
    return like;
  }

  async getLikeByUsers(fromUserId: number, toUserId: number): Promise<Like | undefined> {
    return Array.from(this.likes.values()).find(
      (like) => like.fromUserId === fromUserId && like.toUserId === toUserId
    );
  }

  async getLikesByFromUser(fromUserId: number): Promise<Like[]> {
    return Array.from(this.likes.values()).filter(
      (like) => like.fromUserId === fromUserId
    );
  }

  async getLikesByToUser(toUserId: number): Promise<Like[]> {
    return Array.from(this.likes.values()).filter(
      (like) => like.toUserId === toUserId
    );
  }

  // Match methods
  async createMatch(matchData: InsertMatch): Promise<Match> {
    const id = this.matchId++;
    const now = new Date();
    const match: Match = {
      ...matchData,
      id,
      createdAt: now
    };
    this.matches.set(id, match);
    return match;
  }

  async getMatchesByUser(userId: number): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      (match) => match.user1Id === userId || match.user2Id === userId
    );
  }

  async getMatch(matchId: number): Promise<Match | undefined> {
    return this.matches.get(matchId);
  }

  // Message methods
  async createMessage(messageData: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const now = new Date();
    const message: Message = {
      ...messageData,
      id,
      read: false,
      createdAt: now
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessagesByMatch(matchId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.matchId === matchId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async markMessagesAsRead(messageIds: number[]): Promise<void> {
    for (const messageId of messageIds) {
      const message = this.messages.get(messageId);
      if (message) {
        this.messages.set(messageId, { ...message, read: true });
      }
    }
  }

  async addRevenue(amount: number): Promise<number> {
    this.revenue += amount;
    return this.revenue;
  }

  async getRevenue(): Promise<{total: number, perUser: number}> {
    const userCount = this.users.size;
    return {
      total: this.revenue,
      perUser: userCount > 0 ? this.revenue / userCount : 0
    };
  }
  
  // Méthode pour mettre à jour le statut premium d'un utilisateur
  async updateUserPremiumStatus(id: number, isPremium: boolean, premiumUntil: Date): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { 
      ...user, 
      isPremium,
      premiumUntil
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Méthodes de transaction
  async createTransaction(transactionData: InsertTransaction): Promise<Transaction> {
    const id = this.transactionId++;
    const now = new Date();
    const transaction: Transaction = {
      ...transactionData,
      id,
      createdAt: now,
      completedAt: null
    };
    this.transactions.set(id, transaction);
    
    // Si la transaction est réussie, ajoutons le montant au revenu
    if (transaction.status === 'completed') {
      const amount = Number(transaction.amount);
      if (!isNaN(amount)) {
        await this.addRevenue(amount);
      }
    }
    
    return transaction;
  }
  
  async getTransactionByPayPalOrderId(paypalOrderId: string): Promise<Transaction | undefined> {
    return Array.from(this.transactions.values()).find(
      (transaction) => transaction.paypalOrderId === paypalOrderId
    );
  }
  
  async getTransactionsByUser(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : 0;
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : 0;
        return dateB - dateA; // Pour trier du plus récent au plus ancien
      });
  }
  
  async updateTransactionStatus(id: number, status: string, completedAt?: Date): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (!transaction) return undefined;
    
    const updatedTransaction: Transaction = { 
      ...transaction, 
      status,
      completedAt: completedAt || null
    };
    this.transactions.set(id, updatedTransaction);
    
    // Si le statut passe à 'completed', ajoutons le montant au revenu
    if (status === 'completed' && transaction.status !== 'completed') {
      const amount = Number(transaction.amount);
      if (!isNaN(amount)) {
        await this.addRevenue(amount);
      }
    }
    
    return updatedTransaction;
  }
  
  // Méthodes d'interaction publicitaire
  async createAdInteraction(interactionData: InsertAdInteraction): Promise<AdInteraction> {
    const id = this.adInteractionId++;
    const now = new Date();
    
    // Calculer les revenus en fonction du type d'interaction
    let revenue = 0;
    if (interactionData.type === 'impression') {
      revenue = Number(interactionData.revenue);
    } else if (interactionData.type === 'click') {
      revenue = Number(interactionData.revenue);
    }
    
    const interaction: AdInteraction = {
      ...interactionData,
      id,
      createdAt: now
    };
    
    this.adInteractions.set(id, interaction);
    
    // Ajouter aux revenus publicitaires
    if (!isNaN(revenue) && revenue > 0) {
      this.adRevenue += revenue;
      await this.addRevenue(revenue);
    }
    
    return interaction;
  }
  
  async getAdInteractions(filters?: { adId?: number, userId?: number, type?: string }): Promise<AdInteraction[]> {
    let interactions = Array.from(this.adInteractions.values());
    
    if (filters) {
      if (filters.adId !== undefined) {
        interactions = interactions.filter(interaction => interaction.adId === filters.adId);
      }
      
      if (filters.userId !== undefined) {
        interactions = interactions.filter(interaction => interaction.userId === filters.userId);
      }
      
      if (filters.type) {
        interactions = interactions.filter(interaction => interaction.type === filters.type);
      }
    }
    
    return interactions;
  }
  
  async getAdRevenue(): Promise<number> {
    return this.adRevenue;
  }
  
  // Méthodes de parrainage
  async createReferral(referralData: InsertReferral): Promise<Referral> {
    const id = this.referralId++;
    const now = new Date();
    
    const referral: Referral = {
      ...referralData,
      id,
      status: 'pending',
      reward: null,
      createdAt: now,
      completedAt: null
    };
    
    this.referrals.set(id, referral);
    return referral;
  }
  
  async updateReferralStatus(id: number, status: string, reward: number, completedAt?: Date): Promise<Referral | undefined> {
    const referral = this.referrals.get(id);
    if (!referral) return undefined;
    
    const updatedReferral: Referral = {
      ...referral,
      status,
      reward,
      completedAt: completedAt || null
    };
    
    this.referrals.set(id, updatedReferral);
    
    // Si le statut passe à 'completed', ajoutons la récompense aux revenus
    if (status === 'completed' && referral.status !== 'completed') {
      if (!isNaN(reward) && reward > 0) {
        this.referralRevenue += reward;
        await this.addRevenue(reward);
      }
    }
    
    return updatedReferral;
  }
  
  async getReferralsByUser(userId: number): Promise<Referral[]> {
    return Array.from(this.referrals.values())
      .filter(referral => referral.referrerId === userId || referral.referredId === userId);
  }
  
  async getReferralRevenue(): Promise<number> {
    return this.referralRevenue;
  }
}

export const storage = new MemStorage();
