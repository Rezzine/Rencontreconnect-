import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import { z } from "zod";
import nodemailer from "nodemailer";
import * as paypal from "@paypal/checkout-server-sdk";
import pay from "wechatpay-node-v3";
import {
  insertUserSchema,
  insertLikeSchema,
  insertMessageSchema,
  insertMatchSchema,
  insertTransactionSchema,
  insertAdInteractionSchema,
  insertReferralSchema,
  subscriptionPlans,
  adContents,
  referralRewards
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix
  const apiRouter = express.Router();
  app.use("/api", apiRouter);

  // Helper function to handle validation errors
  const validateRequest = (schema: z.ZodType<any, any>, data: any) => {
    try {
      return schema.parse(data);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        throw new Error(validationError.message);
      }
      throw error;
    }
  };

  // Authentication routes
  const ALLOWED_COUNTRIES = ['JP', 'CN', 'KR', 'TW', 'HK', 'SG'];
  
  apiRouter.post("/auth/register", async (req, res) => {
    try {
      const userData = validateRequest(insertUserSchema, req.body);
      if (!ALLOWED_COUNTRIES.includes(userData.country)) {
        return res.status(400).json({ message: "Service disponible uniquement pour l'Asie de l'Est" });
      }
      const user = await storage.createUser(userData);
      res.status(201).json({ user: { ...user, password: undefined } });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  apiRouter.post("/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Update online status
      await storage.updateUserOnlineStatus(user.id, true);

      res.status(200).json({ user: { ...user, password: undefined } });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  apiRouter.post("/auth/logout", async (req, res) => {
    try {
      const { userId } = req.body;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      await storage.updateUserOnlineStatus(userId, false);
      res.status(200).json({ message: "Logged out successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User routes
  apiRouter.get("/users", async (req, res) => {
    try {
      const filters = req.query;
      const users = await storage.getUsers(filters);
      res.status(200).json(users.map(user => ({ ...user, password: undefined })));
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  apiRouter.get("/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.status(200).json({ ...user, password: undefined });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  apiRouter.put("/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const userData = req.body;
      const updatedUser = await storage.updateUser(userId, userData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      res.status(200).json({ ...updatedUser, password: undefined });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Like/Match routes
  apiRouter.post("/likes", async (req, res) => {
    try {
      const likeData = validateRequest(insertLikeSchema, req.body);
      const like = await storage.createLike(likeData);
      
      // Check if there's a mutual like (match)
      const mutualLike = await storage.getLikeByUsers(likeData.toUserId, likeData.fromUserId);
      if (mutualLike) {
        // Create a match if there's a mutual like
        const matchData = {
          user1Id: likeData.fromUserId,
          user2Id: likeData.toUserId
        };
        const match = await storage.createMatch(matchData);
        res.status(201).json({ like, match, isMatch: true });
      } else {
        res.status(201).json({ like, isMatch: false });
      }
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  apiRouter.get("/likes/sent/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const likes = await storage.getLikesByFromUser(userId);
      res.status(200).json(likes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  apiRouter.get("/likes/received/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const likes = await storage.getLikesByToUser(userId);
      res.status(200).json(likes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Match routes
  apiRouter.get("/matches/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const matches = await storage.getMatchesByUser(userId);
      
      // Get user details for each match
      const matchesWithUsers = await Promise.all(
        matches.map(async (match) => {
          const otherUserId = match.user1Id === userId ? match.user2Id : match.user1Id;
          const otherUser = await storage.getUser(otherUserId);
          return {
            ...match,
            otherUser: otherUser ? { ...otherUser, password: undefined } : null
          };
        })
      );
      
      res.status(200).json(matchesWithUsers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Message routes
  apiRouter.post("/messages", async (req, res) => {
    try {
      const messageData = validateRequest(insertMessageSchema, req.body);
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  apiRouter.get("/messages/match/:matchId", async (req, res) => {
    try {
      const matchId = parseInt(req.params.matchId);
      if (isNaN(matchId)) {
        return res.status(400).json({ message: "Invalid match ID" });
      }

      const messages = await storage.getMessagesByMatch(matchId);
      res.status(200).json(messages);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  apiRouter.put("/messages/read", async (req, res) => {
    try {
      const { messageIds } = req.body;
      if (!Array.isArray(messageIds) || messageIds.length === 0) {
        return res.status(400).json({ message: "Message IDs are required" });
      }

      await storage.markMessagesAsRead(messageIds);
      res.status(200).json({ message: "Messages marked as read" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour envoyer les gains par email
  apiRouter.post("/stats/revenue/send-email", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email requis" });
      }

      const { total, perUser } = await storage.getRevenue();
      
      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASSWORD
        }
      });

      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: email,
        subject: "Vos gains actuels",
        text: `Vos gains actuels sont de ${total} EUR, avec une moyenne de ${perUser} EUR par utilisateur.`
      });

      res.json({ message: "Email envoyé avec succès" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Routes pour les contenus publicitaires
  apiRouter.get("/ads", (_req, res) => {
    try {
      res.status(200).json(adContents);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour créer une interaction publicitaire
  apiRouter.post("/ads/interaction", async (req, res) => {
    try {
      const interactionData = validateRequest(insertAdInteractionSchema, req.body);
      const interaction = await storage.createAdInteraction(interactionData);
      res.status(201).json(interaction);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Route pour obtenir les interactions publicitaires
  apiRouter.get("/ads/interactions", async (req, res) => {
    try {
      const { adId, userId, type } = req.query;
      const filters: { adId?: number, userId?: number, type?: string } = {};
      
      if (adId && !isNaN(Number(adId))) {
        filters.adId = Number(adId);
      }
      
      if (userId && !isNaN(Number(userId))) {
        filters.userId = Number(userId);
      }
      
      if (type && typeof type === 'string') {
        filters.type = type;
      }
      
      const interactions = await storage.getAdInteractions(filters);
      res.status(200).json(interactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour obtenir les revenus publicitaires
  apiRouter.get("/ads/revenue", async (_req, res) => {
    try {
      const adRevenue = await storage.getAdRevenue();
      res.status(200).json({ revenue: adRevenue, currency: "EUR" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Routes pour le système de parrainage
  apiRouter.get("/referral/rewards", (_req, res) => {
    try {
      res.status(200).json(referralRewards);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour créer un parrainage
  apiRouter.post("/referral", async (req, res) => {
    try {
      const referralData = validateRequest(insertReferralSchema, req.body);
      const referral = await storage.createReferral(referralData);
      res.status(201).json(referral);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Route pour obtenir les parrainages d'un utilisateur
  apiRouter.get("/referral/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "ID utilisateur invalide" });
      }
      
      const referrals = await storage.getReferralsByUser(userId);
      res.status(200).json(referrals);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour mettre à jour le statut d'un parrainage
  apiRouter.put("/referral/:id", async (req, res) => {
    try {
      const referralId = parseInt(req.params.id);
      if (isNaN(referralId)) {
        return res.status(400).json({ message: "ID de parrainage invalide" });
      }
      
      const { status, reward } = req.body;
      if (!status || typeof reward !== 'number') {
        return res.status(400).json({ 
          message: "Le statut et la récompense sont requis"
        });
      }
      
      const updatedReferral = await storage.updateReferralStatus(
        referralId,
        status,
        reward,
        status === 'completed' ? new Date() : undefined
      );
      
      if (!updatedReferral) {
        return res.status(404).json({ message: "Parrainage non trouvé" });
      }
      
      res.status(200).json(updatedReferral);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour obtenir les revenus des parrainages
  apiRouter.get("/referral/revenue", async (_req, res) => {
    try {
      const referralRevenue = await storage.getReferralRevenue();
      res.status(200).json({ revenue: referralRevenue, currency: "EUR" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour obtenir les gains en temps réel
  apiRouter.get("/stats/revenue", async (_req, res) => {
    try {
      const { total, perUser } = await storage.getRevenue();
      res.json({ 
        revenue: total,
        revenuePerUser: perUser,
        currency: "EUR",
        lastUpdated: new Date()
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Route pour ajouter des gains
  apiRouter.post("/stats/revenue", async (req, res) => {
    try {
      const { amount } = req.body;
      if (typeof amount !== 'number') {
        return res.status(400).json({ message: "Le montant doit être un nombre" });
      }
      const newRevenue = await storage.addRevenue(amount);
      res.json({ 
        revenue: newRevenue,
        currency: "EUR",
        lastUpdated: new Date()
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Vérification des clés PayPal
  const paypalClientId = process.env.PAYPAL_CLIENT_ID;
  const paypalClientSecret = process.env.PAYPAL_CLIENT_SECRET;
  
  // Vérification des clés WeChat Pay
  const wechatPayAppId = process.env.WECHAT_PAY_APP_ID;
  const wechatPayMchId = process.env.WECHAT_PAY_MCH_ID;
  const wechatPayApiKey = process.env.WECHAT_PAY_API_KEY;
  const wechatPayCertSerialNo = process.env.WECHAT_PAY_CERT_SERIAL_NO;
  
  // Helper function to create PayPal environment
  function getPayPalEnvironment() {
    if (!paypalClientId || !paypalClientSecret) {
      throw new Error("PayPal API credentials are missing");
    }
    
    // Détermine l'environnement basé sur NODE_ENV ou utilise sandbox par défaut
    const isProduction = process.env.NODE_ENV === 'production';
    if (isProduction) {
      return new paypal.core.LiveEnvironment(paypalClientId, paypalClientSecret);
    } else {
      return new paypal.core.SandboxEnvironment(paypalClientId, paypalClientSecret);
    }
  }
  
  // Helper function to create WeChat Pay instance
  function getWeChatPayInstance() {
    if (!wechatPayAppId || !wechatPayMchId || !wechatPayApiKey || !wechatPayCertSerialNo) {
      throw new Error("WeChat Pay API credentials are missing");
    }
    
    return new pay({
      appid: wechatPayAppId,
      mchid: wechatPayMchId,
      publicKey: wechatPayApiKey,
      privateKey: wechatPayApiKey,
      serialno: wechatPayCertSerialNo,
      key: wechatPayApiKey
    });
  }
  
  // PayPal routes
  apiRouter.get("/subscription/plans", (_req, res) => {
    try {
      res.status(200).json(subscriptionPlans);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  apiRouter.post("/paypal/create-order", async (req, res) => {
    try {
      // Vérifie si les clés PayPal sont configurées
      if (!paypalClientId || !paypalClientSecret) {
        return res.status(500).json({ 
          message: "PayPal n'est pas configuré. Contactez l'administrateur."
        });
      }
      
      const { userId, planId } = req.body;
      if (!userId || !planId) {
        return res.status(400).json({ 
          message: "L'ID de l'utilisateur et l'ID du plan sont requis" 
        });
      }
      
      // Trouver le plan correspondant
      const plan = subscriptionPlans.find(p => p.id === planId);
      if (!plan) {
        return res.status(404).json({ message: "Plan d'abonnement non trouvé" });
      }
      
      // Créer l'environnement PayPal et le client
      const env = getPayPalEnvironment();
      const client = new paypal.core.PayPalHttpClient(env);
      
      // Créer la demande d'ordre
      const request = new paypal.orders.OrdersCreateRequest();
      request.prefer("return=representation");
      
      // Définir les détails de la commande
      request.requestBody({
        intent: "CAPTURE",
        purchase_units: [
          {
            reference_id: `plan_${planId}`,
            description: `Abonnement ${plan.name} - Dating App`,
            amount: {
              currency_code: "EUR",
              value: plan.price.toString()
            }
          }
        ],
        application_context: {
          brand_name: "Dating App",
          landing_page: "BILLING",
          user_action: "PAY_NOW",
          return_url: `${req.protocol}://${req.get('host')}/api/paypal/capture-order`,
          cancel_url: `${req.protocol}://${req.get('host')}/premium`
        }
      });
      
      // Exécuter la demande
      const order = await client.execute(request);
      
      // Créer une transaction en attente
      const transactionData = {
        userId,
        paypalOrderId: order.result.id,
        amount: parseFloat(plan.price.toString()),
        currency: "EUR",
        status: "pending",
        planId: plan.id
      };
      
      const transaction = await storage.createTransaction(transactionData);
      
      res.status(200).json({
        orderId: order.result.id,
        transactionId: transaction.id,
        links: order.result.links
      });
    } catch (error: any) {
      console.error("Erreur lors de la création de la commande PayPal:", error);
      res.status(500).json({ 
        message: "Erreur lors de la création de la commande PayPal",
        error: error.message 
      });
    }
  });
  
  apiRouter.post("/paypal/capture-order", async (req, res) => {
    try {
      const { orderId } = req.body;
      if (!orderId) {
        return res.status(400).json({ message: "Order ID is required" });
      }
      
      // Vérifie si les clés PayPal sont configurées
      if (!paypalClientId || !paypalClientSecret) {
        return res.status(500).json({ 
          message: "PayPal n'est pas configuré. Contactez l'administrateur."
        });
      }
      
      // Créer l'environnement PayPal et le client
      const env = getPayPalEnvironment();
      const client = new paypal.core.PayPalHttpClient(env);
      
      // Créer la demande de capture
      const request = new paypal.orders.OrdersCaptureRequest(orderId);
      request.prefer("return=representation");
      
      // Exécuter la demande
      const capture = await client.execute(request);
      
      // Trouver la transaction correspondante
      const transaction = await storage.getTransactionByPayPalOrderId(orderId);
      if (!transaction) {
        return res.status(404).json({ message: "Transaction non trouvée" });
      }
      
      // Mettre à jour le statut de la transaction
      const status = capture.result.status === "COMPLETED" ? "completed" : "failed";
      const updatedTransaction = await storage.updateTransactionStatus(
        transaction.id,
        status,
        new Date()
      );
      
      res.status(200).json({
        transaction: updatedTransaction,
        captureId: capture.result.id,
        status: capture.result.status
      });
    } catch (error: any) {
      console.error("Erreur lors de la capture de la commande PayPal:", error);
      res.status(500).json({ 
        message: "Erreur lors de la capture de la commande PayPal",
        error: error.message 
      });
    }
  });
  
  apiRouter.get("/transactions/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const transactions = await storage.getTransactionsByUser(userId);
      res.status(200).json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Routes WeChat Pay
  apiRouter.post("/wechatpay/create-order", async (req, res) => {
    try {
      // Vérifie si les clés WeChat Pay sont configurées
      if (!wechatPayAppId || !wechatPayMchId || !wechatPayApiKey || !wechatPayCertSerialNo) {
        return res.status(500).json({ 
          message: "WeChat Pay n'est pas configuré. Contactez l'administrateur."
        });
      }
      
      const { userId, planId } = req.body;
      if (!userId || !planId) {
        return res.status(400).json({ 
          message: "L'ID de l'utilisateur et l'ID du plan sont requis" 
        });
      }
      
      // Trouver le plan correspondant
      const plan = subscriptionPlans.find(p => p.id === planId);
      if (!plan) {
        return res.status(404).json({ message: "Plan d'abonnement non trouvé" });
      }
      
      try {
        // Créer l'instance WeChat Pay
        const wechatPayInstance = getWeChatPayInstance();
        
        // Générer un numéro de commande unique
        const outTradeNo = `order_${Date.now()}_${userId}_${planId}`;
        
        // Créer la demande de paiement
        const params = {
          description: `Abonnement ${plan.name} - Dating App`,
          out_trade_no: outTradeNo,
          amount: {
            total: Math.round(plan.price * 100) // WeChat Pay utilise les centimes
          },
          notify_url: `${req.protocol}://${req.get('host')}/api/wechatpay/notify`
        };
        
        // Créer l'URL de paiement
        const result = await wechatPayInstance.transactions_native(params);
        const qrCodeURL = result.code_url;
        
        // Créer une transaction en attente
        const transactionData = {
          userId: parseInt(userId),
          paypalOrderId: outTradeNo, // Utiliser le même champ pour stocker l'identifiant WeChat
          amount: plan.price.toString(),
          currency: "CNY", // Yuan chinois
          status: "pending",
          planId: plan.id
        };
        
        const transaction = await storage.createTransaction(transactionData);
        
        res.status(200).json({
          orderId: outTradeNo,
          transactionId: transaction.id,
          qrCodeURL: qrCodeURL,
          provider: "wechatpay"
        });
      } catch (error: any) {
        console.error("Erreur lors de la création de la commande WeChat Pay:", error);
        res.status(500).json({ 
          message: "Erreur lors de la création de la commande WeChat Pay",
          error: error.message 
        });
      }
    } catch (error: any) {
      console.error("Erreur dans la route WeChat Pay:", error);
      res.status(500).json({ 
        message: "Erreur dans la route WeChat Pay",
        error: error.message 
      });
    }
  });
  
  // Route pour recevoir les notifications de paiement WeChat Pay
  apiRouter.post("/wechatpay/notify", async (req, res) => {
    try {
      if (!wechatPayAppId || !wechatPayMchId || !wechatPayApiKey || !wechatPayCertSerialNo) {
        return res.status(500).json({ message: "WeChat Pay non configuré" });
      }
      
      const wechatPayInstance = getWeChatPayInstance();
      
      // Vérifier la signature de la notification
      const result = wechatPayInstance.parseNotifyData(req);
      
      // Si le paiement est réussi
      if (result.event_type === 'TRANSACTION.SUCCESS') {
        const outTradeNo = result.resource.out_trade_no;
        
        // Trouver la transaction correspondante
        const transaction = await storage.getTransactionByPayPalOrderId(outTradeNo);
        if (!transaction) {
          return res.status(404).json({ message: "Transaction non trouvée" });
        }
        
        // Mettre à jour le statut de la transaction
        const updatedTransaction = await storage.updateTransactionStatus(
          transaction.id,
          "completed",
          new Date()
        );
        
        // Mettre à jour le statut premium de l'utilisateur
        if (updatedTransaction) {
          const plan = subscriptionPlans.find(p => p.id === updatedTransaction.planId);
          if (plan) {
            const premiumUntil = new Date();
            premiumUntil.setDate(premiumUntil.getDate() + plan.duration);
            
            await storage.updateUserPremiumStatus(
              updatedTransaction.userId, 
              true, 
              premiumUntil
            );
          }
        }
        
        // Répondre à WeChat Pay
        return res.status(200).json({
          code: "SUCCESS",
          message: "Notification reçue avec succès"
        });
      }
      
      res.status(200).json({
        code: "FAIL",
        message: "Statut de paiement invalide"
      });
    } catch (error: any) {
      console.error("Erreur lors du traitement de la notification WeChat Pay:", error);
      res.status(500).json({ 
        code: "FAIL",
        message: error.message 
      });
    }
  });
  
  // Route pour vérifier le statut d'un paiement WeChat Pay
  apiRouter.get("/wechatpay/order-status/:outTradeNo", async (req, res) => {
    try {
      if (!wechatPayAppId || !wechatPayMchId || !wechatPayApiKey || !wechatPayCertSerialNo) {
        return res.status(500).json({ 
          message: "WeChat Pay n'est pas configuré. Contactez l'administrateur."
        });
      }
      
      const { outTradeNo } = req.params;
      if (!outTradeNo) {
        return res.status(400).json({ message: "Numéro de commande requis" });
      }
      
      const wechatPayInstance = getWeChatPayInstance();
      
      // Vérifier le statut du paiement auprès de WeChat Pay
      const result = await wechatPayInstance.query({
        out_trade_no: outTradeNo
      });
      
      // Trouver la transaction correspondante
      const transaction = await storage.getTransactionByPayPalOrderId(outTradeNo);
      if (!transaction) {
        return res.status(404).json({ message: "Transaction non trouvée" });
      }
      
      // Si le paiement est réussi mais que notre transaction est toujours en attente
      if (result.trade_state === 'SUCCESS' && transaction.status === 'pending') {
        // Mettre à jour le statut de la transaction
        const updatedTransaction = await storage.updateTransactionStatus(
          transaction.id,
          "completed",
          new Date()
        );
        
        // Mettre à jour le statut premium de l'utilisateur
        if (updatedTransaction) {
          const plan = subscriptionPlans.find(p => p.id === updatedTransaction.planId);
          if (plan) {
            const premiumUntil = new Date();
            premiumUntil.setDate(premiumUntil.getDate() + plan.duration);
            
            await storage.updateUserPremiumStatus(
              updatedTransaction.userId, 
              true, 
              premiumUntil
            );
          }
        }
      }
      
      res.status(200).json({
        transactionId: transaction.id,
        status: result.trade_state,
        orderStatus: transaction.status,
        provider: "wechatpay"
      });
    } catch (error: any) {
      console.error("Erreur lors de la vérification du statut WeChat Pay:", error);
      res.status(500).json({ 
        message: "Erreur lors de la vérification du statut WeChat Pay",
        error: error.message 
      });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
